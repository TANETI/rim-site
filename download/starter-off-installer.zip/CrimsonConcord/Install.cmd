@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0installer\Modpack-UI.ps1"
if errorlevel 1 pause