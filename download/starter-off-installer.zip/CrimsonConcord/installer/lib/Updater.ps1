﻿<#
.SYNOPSIS
  우리가 만든 모드(local-mods)의 최신본을 가져와 설치본을 갱신한다.

.DESCRIPTION
  이 파일은 dot-source 로만 쓴다.

  ── 이 기능이 필요한 이유 ──────────────────────────────────────────
  Workshop 모드 99개는 Steam 이 알아서 갱신하고 RimSort 가 알려 준다.
  우리가 직접 챙겨야 하는 것은 **우리가 만든 것뿐**이다.
  진조이니라 본체와 선택 모듈, 호환 패치, 한국어 보정 모드.

  ── 버전을 어떻게 비교하나 ─────────────────────────────────────────
  우리 모드에는 버전 표기가 없다. 새로 만들어 붙이는 대신
  **파일 내용 해시**로 비교한다.

    모드 폴더의 모든 파일을 상대 경로 순으로 정렬
      → 각 파일의 SHA-256 을 이어 붙여 다시 SHA-256
      → 그 값이 그 모드의 지문

  버전 문자열을 사람이 올리는 것을 잊어도 어긋나지 않는다.
  Source 폴더와 .git 은 지문에서 뺀다. 설치본에는 어차피 가지 않는다.

  ── 어디서 가져오나 ────────────────────────────────────────────────
  `-Source` 로 정한다.

    github:소유자/저장소[@가지]   공개 저장소의 zip 을 받는다
    local:경로                    이미 있는 작업 사본에서 가져온다

  🔴 이 프로젝트의 저장소는 Private 이다. github: 를 쓰려면
     **local-mods 만 담은 공개 미러 저장소가 먼저 있어야 한다**
     (설계 4절 B안). 아직 만들지 않았다.
     그래서 지금 실제로 동작하는 것은 local: 쪽이다 —
     두 컴퓨터를 오가는 지금 상황에서는 이쪽이 오히려 쓸모가 있다.

  설치기는 어떤 경우에도 GitHub 토큰을 묻거나 파일에 남기지 않는다.
  비공개 저장소를 대상으로 쓰지 마라.
#>

# Source 폴더와 저장소 부산물은 설치본에 가지 않는다. 지문에서도 뺀다.
# README.md 는 개발용 메모라 설치본에 가지 않는다. 지문에 넣으면
# 있지도 않은 갱신이 매번 잡힌다(실제로 ComplementaryOdysseyLightingFix 가 그랬다).
$script:UpdaterExclude = @(
    '\.git($|\\)', '(^|\\)Source(\\|$)', '(^|\\)\.vs(\\|$)',
    '\.psd$', '\.afdesign$', '(^|\\)README\.md$',
    # 00.png 은 저장소 규약상 동기화하지 않는다. 그래서 배포 묶음에도 안 들어간다.
    # 지문에 남겨 두면 배포본에는 없고 설치본에는 있어서 **영원히 "갱신 필요"** 가 뜬다.
    # (2026-09-01, 묶음으로 설치기를 돌려 보다 발견. README.md 와 같은 유형)
    '(^|\\)Defs\\00\.png$'
)

function Test-UpdaterExcluded {
    param([Parameter(Mandatory)][string]$RelativePath)
    foreach ($p in $script:UpdaterExclude) {
        if ($RelativePath -match $p) { return $true }
    }
    return $false
}

<#
  모드 폴더 하나의 지문. 폴더가 없으면 $null.
#>
function Get-ModFingerprint {
    param([Parameter(Mandatory)][string]$Folder)
    if (-not (Test-Path $Folder)) { return $null }

    $files = Get-ChildItem $Folder -Recurse -File -ErrorAction SilentlyContinue |
        ForEach-Object {
            $rel = $_.FullName.Substring($Folder.Length).TrimStart('\')
            if (Test-UpdaterExcluded $rel) { return }
            [pscustomobject]@{ Rel = $rel; Path = $_.FullName }
        } | Where-Object { $_ } | Sort-Object { $_.Rel.ToLower() }

    if (-not $files) { return $null }

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $acc = New-Object System.Text.StringBuilder
        foreach ($f in $files) {
            $h = (Get-FileHash -Path $f.Path -Algorithm SHA256).Hash
            [void]$acc.Append($f.Rel.ToLower()).Append(':').Append($h).Append("`n")
        }
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($acc.ToString())
        return ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-', '')
    } finally { $sha.Dispose() }
}

<#
  모드 폴더의 파일별 SHA-256. 지문의 재료이자 무결성 검증의 근거다.
  돌려주는 것은 상대경로(소문자) → 해시 의 해시테이블.
#>
function Get-ModFileHashes {
    param([Parameter(Mandatory)][string]$Folder)
    $map = @{}
    if (-not (Test-Path $Folder)) { return $map }
    foreach ($f in Get-ChildItem $Folder -Recurse -File -ErrorAction SilentlyContinue) {
        $rel = $f.FullName.Substring($Folder.Length).TrimStart('\')
        if (Test-UpdaterExcluded $rel) { continue }
        $map[$rel.ToLower()] = (Get-FileHash -Path $f.FullName -Algorithm SHA256).Hash
    }
    return ,$map
}

<#
  배포용 무결성 색인을 만든다. 사이트가 이 파일을 함께 올리고
  설치기가 받아서 대조한다.

  🔴 이것이 막는 것과 막지 못하는 것을 분명히 해 둔다.

    막는다   : 내려받다 끊긴 zip, 압축이 덜 풀린 트리, 디스크 손상,
               설치 도중 죽어 반쯤 덮인 폴더
    못 막는다: 배포처 자체가 바뀐 경우. 그건 서명이 필요하고
               우리는 서명하지 않는다. 색인도 같은 곳에서 오기 때문이다.

  과장해서 적지 마라. 이건 손상 검출이지 진위 검증이 아니다.
#>
function New-LocalModsIndex {
    param(
        [Parameter(Mandatory)][string]$LocalMods,
        [Parameter(Mandatory)][string]$OutFile
    )
    $mods = [ordered]@{}
    foreach ($dir in (Get-ChildItem $LocalMods -Directory | Sort-Object Name)) {
        if (-not (Test-Path (Join-Path $dir.FullName "About\About.xml"))) { continue }
        $files = Get-ModFileHashes -Folder $dir.FullName
        $bytes = 0
        foreach ($f in Get-ChildItem $dir.FullName -Recurse -File) {
            $rel = $f.FullName.Substring($dir.FullName.Length).TrimStart('\')
            if (Test-UpdaterExcluded $rel) { continue }
            $bytes += $f.Length
        }
        $mods[$dir.Name] = [ordered]@{
            fingerprint = Get-ModFingerprint -Folder $dir.FullName
            fileCount   = $files.Count
            bytes       = $bytes
            files       = [ordered]@{}
        }
        foreach ($k in ($files.Keys | Sort-Object)) { $mods[$dir.Name].files[$k] = $files[$k] }
    }

    $index = [ordered]@{
        schema    = 1
        generated = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
        note      = "손상 검출용이다. 진위 검증이 아니다 — 색인도 같은 배포처에서 온다."
        mods      = $mods
    }
    Write-JsonUtf8 -Object $index -Path $OutFile -Depth 8
    return [pscustomobject]@{ Path = $OutFile; ModCount = $mods.Count }
}

<#
  받아 온 원본을 색인과 대조한다. 아무것도 설치하지 않는다.
  한 파일이라도 어긋나면 그 모드는 통째로 막는다 — 반만 맞은 설치가
  가장 고치기 어렵다.
#>
function Test-SourceIntegrity {
    param(
        [Parameter(Mandatory)][string]$SourceLocalMods,
        [Parameter(Mandatory)][string]$IndexPath
    )
    $index = Read-JsonUtf8 $IndexPath
    if (-not $index -or -not $index.mods) { throw "무결성 색인을 읽지 못했다: $IndexPath" }

    $rows = @()
    foreach ($entry in $index.mods.PSObject.Properties) {
        $about = Join-Path (Join-Path $SourceLocalMods $entry.Name) 'About\About.xml'
        if (-not (Test-Path -LiteralPath $about)) {
            $rows += [pscustomobject]@{ Name=$entry.Name; Ok=$false; Reason='색인에 있는 모드 폴더 또는 About.xml이 없다'; BadCount=1 }
        }
    }
    foreach ($dir in (Get-ChildItem $SourceLocalMods -Directory | Sort-Object Name)) {
        if (-not (Test-Path (Join-Path $dir.FullName "About\About.xml"))) { continue }
        $entry = $index.mods.PSObject.Properties[$dir.Name]
        if (-not $entry) {
            $rows += [pscustomobject]@{ Name = $dir.Name; Ok = $false; Reason = "색인에 없는 모드다" }
            continue
        }
        $expected = $entry.Value
        $actual = Get-ModFileHashes -Folder $dir.FullName

        $bad = @()
        foreach ($p in $expected.files.PSObject.Properties) {
            if (-not $actual.ContainsKey($p.Name)) { $bad += "없음 $($p.Name)"; continue }
            if ($actual[$p.Name] -ne $p.Value)     { $bad += "다름 $($p.Name)" }
        }
        foreach ($k in $actual.Keys) {
            if (-not $expected.files.PSObject.Properties[$k]) { $bad += "여분 $k" }
        }

        $rows += [pscustomobject]@{
            Name   = $dir.Name
            Ok     = ($bad.Count -eq 0)
            Reason = if ($bad.Count) { ($bad | Select-Object -First 4) -join ", " } else { "" }
            BadCount = $bad.Count
        }
    }
    return $rows
}

<#
  덮어쓰기 전에 설치본을 통째로 복사해 둔다.
  ModsConfig 는 백업하면서 모드 폴더는 안 하고 있었다.
  DLL 이 든 폴더를 덮어쓰는데 되돌릴 길이 없으면 안 된다.

  게임 폴더 안에 두지 않는다 — RimWorld 와 RimSort 가 모드로 오인한다.
#>
function Get-ModBackupRoot {
    param([string]$Stamp)
    if (-not $Stamp) { $Stamp = (Get-Date).ToString("yyyyMMdd-HHmmss") }
    return (Join-Path $env:LOCALAPPDATA "CrimsonConcord\mod-backups\$Stamp")
}

function Backup-InstalledMod {
    param(
        [Parameter(Mandatory)][string]$Installed,
        [Parameter(Mandatory)][string]$BackupRoot
    )
    if (-not (Test-Path $Installed)) { return $null }
    $dest = Join-Path $BackupRoot (Split-Path $Installed -Leaf)
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    Copy-Item (Join-Path $Installed "*") $dest -Recurse -Force -ErrorAction Stop
    return $dest
}

<#
  무결성 색인을 찾는다. local-mods 옆이나 그 부모에 있다.
  없으면 $null — 색인 없이도 갱신은 되지만 대조는 못 한다.
#>
function Find-LocalModsIndex {
    param([Parameter(Mandatory)][string]$Near)
    $parent = Split-Path $Near -Parent
    foreach ($c in @(
        (Join-Path $Near "local-mods.index.json"),
        (Join-Path $parent "local-mods.index.json"),
        (Join-Path $parent "site\dist\local-mods.index.json"))) {
        if (Test-Path $c) { return $c }
    }
    return $null
}

<#
  최신본을 받아 풀어 둔 곳의 local-mods 경로를 돌려준다.
#>
function Get-UpdateSource {
    param(
        [Parameter(Mandatory)][string]$Source,
        [string]$WorkDir
    )
    if (-not $WorkDir) { $WorkDir = Join-Path $env:TEMP "crimson-concord-update" }

    if ($Source -match '^local:(.+)$') {
        $path = $Matches[1].Trim()
        $localMods = if ((Split-Path $path -Leaf) -eq 'local-mods') { $path } else { Join-Path $path "local-mods" }
        if (-not (Test-Path $localMods)) { throw "local-mods 를 찾지 못했다: $localMods" }
        Write-Ok "원본 : $localMods"
        return [pscustomobject]@{
            LocalMods = $localMods; Temp = $null; Label = "local"
            IndexPath = Find-LocalModsIndex -Near $localMods
        }
    }

    if ($Source -match '^github:([^/]+)/([^@]+)(@(.+))?$') {
        $owner = $Matches[1]; $repo = $Matches[2]; $branch = if ($Matches[4]) { $Matches[4] } else { "main" }
        $url = "https://codeload.github.com/$owner/$repo/zip/refs/heads/$branch"
        Write-Step "GitHub 에서 받기 — $owner/$repo@$branch"

        if (Test-Path $WorkDir) { Remove-Item $WorkDir -Recurse -Force -ErrorAction SilentlyContinue }
        New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null
        $zip = Join-Path $WorkDir "src.zip"

        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        $wc.Headers.Add("User-Agent", "crimson-concord-installer")
        try { $wc.DownloadFile($url, $zip) }
        catch {
            throw ("받지 못했다: $url`n" +
                   "  공개 저장소가 맞는지 확인해라. 비공개 저장소는 이 방식으로 받을 수 없고,`n" +
                   "  설치기는 토큰을 다루지 않는다. 원문: $($_.Exception.Message)")
        }
        finally { $wc.Dispose() }

        Expand-Archive -Path $zip -DestinationPath $WorkDir -Force
        $extracted = Get-ChildItem $WorkDir -Directory | Select-Object -First 1
        if (-not $extracted) { throw "압축을 풀었는데 내용이 없다" }

        $localMods = Join-Path $extracted.FullName "local-mods"
        if (-not (Test-Path $localMods)) {
            # 미러 저장소가 local-mods 를 최상위로 두는 경우도 받아 준다.
            $localMods = $extracted.FullName
        }
        Write-Ok "원본 : $localMods"
        return [pscustomobject]@{
            LocalMods = $localMods; Temp = $WorkDir; Label = "$owner/$repo@$branch"
            IndexPath = Find-LocalModsIndex -Near $localMods
        }
    }

    throw "Source 형식을 모르겠다: $Source`n  github:소유자/저장소[@가지] 또는 local:경로"
}

<#
  최신본과 설치본을 대조한다. 아무것도 바꾸지 않는다.
#>
function Compare-LocalMods {
    param(
        [Parameter(Mandatory)][string]$SourceLocalMods,
        [Parameter(Mandatory)][string]$RimWorldPath,
        [string[]]$Only
    )
    $modsRoot = Join-Path $RimWorldPath "Mods"
    $rows = @()

    foreach ($dir in Get-ChildItem $SourceLocalMods -Directory) {
        if ($Only -and $Only -notcontains $dir.Name) { continue }
        $about = Join-Path $dir.FullName "About\About.xml"
        if (-not (Test-Path $about)) { continue }

        $installed = Join-Path $modsRoot $dir.Name
        $srcFp = Get-ModFingerprint -Folder $dir.FullName
        $dstFp = Get-ModFingerprint -Folder $installed

        $state = if (-not $dstFp) { "새로 설치" }
                 elseif ($srcFp -eq $dstFp) { "최신" }
                 else { "갱신 필요" }

        $rows += [pscustomobject]@{
            Name      = $dir.Name
            State     = $state
            Source    = $dir.FullName
            Installed = $installed
            SrcHash   = if ($srcFp) { $srcFp.Substring(0, 12) } else { "" }
            DstHash   = if ($dstFp) { $dstFp.Substring(0, 12) } else { "" }
        }
    }
    return $rows
}

<#
  실제로 덮어쓴다. Source 폴더는 옮기지 않는다.

  ⚠ local-mods/CrimsonConcord/Defs/00.png 은 저장소 규약상 동기화 대상이 아니다.
    설치본에 이미 있는 것을 그대로 둔다.
#>
$script:UpdaterSkipFiles = @('Defs\00.png')

function Update-LocalMods {
    param(
        [Parameter(Mandatory)]$Comparison,
        [switch]$WhatIf,
        [string]$IndexPath,
        [string]$SourceLocalMods,
        [switch]$NoBackup,
        [string]$BackupRoot
    )
    $changed = @($Comparison | Where-Object { $_.State -ne "최신" })

    # ── 무결성 대조 ────────────────────────────────────────────────
    # 손상된 원본으로 DLL 을 덮어쓰는 것보다는 아무것도 안 하는 편이 낫다.
    if ($IndexPath -and $SourceLocalMods) {
        Write-Step "원본 무결성 대조"
        $verdict = Test-SourceIntegrity -SourceLocalMods $SourceLocalMods -IndexPath $IndexPath
        $blocked = @{}
        foreach ($v in $verdict) {
            if ($v.Ok) { continue }
            $blocked[$v.Name] = $v.Reason
            Write-Fail "$($v.Name) — $($v.Reason)"
        }
        if ($blocked.Count) {
            throw "원본 무결성 오류 $($blocked.Count)건. 모드와 배열 적용을 중단한다. 설치 묶음을 다시 받아라."
        } else {
            Write-Ok "$($verdict.Count)개 전부 색인과 일치한다"
        }
    } elseif (-not $WhatIf) {
        Write-Warn "무결성 색인이 없어 대조 없이 진행한다 (local: 원본이면 정상이다)"
    }

    if (-not $changed.Count) { Write-Ok "전부 최신이다"; return @() }
    if (-not $BackupRoot) { $BackupRoot = Get-ModBackupRoot }

    Write-Step "갱신 $($changed.Count)개"
    $done = @()
    foreach ($row in $changed) {
        Write-Info "$($row.State) : $($row.Name)"
        if ($WhatIf) { continue }

        if (Test-Path $row.Installed) {
            if ($NoBackup) {
                Write-Warn "  백업 없이 덮어쓴다 (-NoBackup)"
            } else {
                try {
                    $saved = Backup-InstalledMod -Installed $row.Installed -BackupRoot $BackupRoot
                    Write-Info "  백업 : $saved"
                } catch {
                    throw "백업 실패 — 모드와 배열 적용 중단: $($_.Exception.Message)"
                }
            }
        } else {
            New-Item -ItemType Directory -Path $row.Installed -Force | Out-Null
        }

        # 설치본에만 있는 파일은 지운다. 옛 Def 가 남아 교차참조 오류를 내는 것을 막는다.
        $srcRels = @{}
        foreach ($f in Get-ChildItem $row.Source -Recurse -File) {
            $rel = $f.FullName.Substring($row.Source.Length).TrimStart('\')
            if (Test-UpdaterExcluded $rel) { continue }
            $srcRels[$rel.ToLower()] = $true
        }
        foreach ($f in Get-ChildItem $row.Installed -Recurse -File -ErrorAction SilentlyContinue) {
            $rel = $f.FullName.Substring($row.Installed.Length).TrimStart('\')
            if ($script:UpdaterSkipFiles -contains $rel) { continue }
            if (-not $srcRels.ContainsKey($rel.ToLower())) {
                Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop
            }
        }

        foreach ($f in Get-ChildItem $row.Source -Recurse -File) {
            $rel = $f.FullName.Substring($row.Source.Length).TrimStart('\')
            if (Test-UpdaterExcluded $rel) { continue }
            if ($script:UpdaterSkipFiles -contains $rel) { Write-Info "  건너뜀(규약): $rel"; continue }
            $dst = Join-Path $row.Installed $rel
            $dstDir = Split-Path $dst -Parent
            if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
            Copy-Item $f.FullName $dst -Force
        }
        if ((Get-ModFingerprint -Folder $row.Source) -ne (Get-ModFingerprint -Folder $row.Installed)) {
            throw "설치 후 검증 실패: $($row.Name). 배열을 적용하지 않는다. 백업: $BackupRoot"
        }
        Write-Ok "  완료"
        $done += $row
    }
    return $done
}
