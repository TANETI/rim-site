﻿<#
.SYNOPSIS
  선택 집합 → ModsConfig.xml 생성. 갈래(variants) 해석과 의존성 연쇄 포함.

.DESCRIPTION
  이 파일은 dot-source 로만 쓴다.

  ⚠ 순서는 사용자가 고르지 않는다. 매니페스트의 order 를 그대로 따른다.
    Revia 처럼 자기 loadAfter 선언대로 두면 VEF play data 로딩이 실패하는
    검증된 예외가 여럿이라, 검증된 배열 순서를 손대게 두면 안 된다.
#>

<#
  갈래 선택을 모드 집합에 반영한다.
  Selections 는 @{ hygiene = "lite" } 형태.
#>
function Resolve-Variants {
    param(
        [Parameter(Mandatory)]$Manifest,
        [Parameter(Mandatory)][hashtable]$Selections,
        [Parameter(Mandatory)][System.Collections.Generic.HashSet[string]]$Enabled
    )
    foreach ($v in $Manifest.variants) {
        $chosenId = if ($Selections.ContainsKey($v.id)) { $Selections[$v.id] } else { $v.default }
        $opt = $v.options | Where-Object { $_.id -eq $chosenId } | Select-Object -First 1
        if (-not $opt) { throw "갈래 '$($v.id)' 에 '$chosenId' 라는 선택지가 없다." }

        foreach ($x in @($opt.exclude)) { if ($x) { [void]$Enabled.Remove($x) } }
        foreach ($i in @($opt.include)) { if ($i) { [void]$Enabled.Add($i) } }
    }
    return $Enabled
}

<#
  requires 를 따라 필요한 것을 켠다. 켜는 쪽만 연쇄한다.
  끄는 쪽 연쇄(A 를 끄면 A 를 요구하는 B 도 끈다)는 Remove-Dependents 가 한다.
#>
function Add-RequiredDependencies {
    param(
        [Parameter(Mandatory)]$Manifest,
        [Parameter(Mandatory)][System.Collections.Generic.HashSet[string]]$Enabled
    )
    $byId = @{}
    foreach ($m in $Manifest.mods) { $byId[$m.packageId] = $m }

    $changed = $true
    $guard = 0
    while ($changed) {
        $changed = $false
        if (++$guard -gt 50) { throw "의존성 연쇄가 끝나지 않는다. requires 에 순환이 있는지 확인해라." }
        foreach ($id in @($Enabled)) {
            $m = $byId[$id]
            if (-not $m) { continue }
            foreach ($r in @($m.requires)) {
                if ($r -and -not $Enabled.Contains($r)) { [void]$Enabled.Add($r); $changed = $true }
            }
        }
    }
    return $Enabled
}

<#
  꺼진 모드를 요구하는 모드를 함께 끈다.
  무엇이 함께 꺼지는지 목록으로 돌려준다 — 사용자에게 먼저 보여줘야 한다.

  ── requires 와 onlyIf 는 다르다 (2026-09-01) ──────────────────────
  requires : "이게 없으면 나는 못 돈다." Add-RequiredDependencies 가
             먼저 돌면서 없는 것을 **켜 준다.**
  onlyIf   : "이게 없으면 내가 있을 이유가 없다." 켜 주지 않는다.
             없으면 나를 **끈다.**

  호환 패치가 이 차이를 필요로 한다. Wolfein 음성 핫픽스에 requires 를 달면
  종족 묶음을 꺼도 Wolfein 이 도로 켜진다 — 정반대다.
  plain 프리셋을 만들다 실제로 밟았다(74개가 80개로 늘었다).
#>
function Remove-Dependents {
    param(
        [Parameter(Mandatory)]$Manifest,
        [Parameter(Mandatory)][System.Collections.Generic.HashSet[string]]$Enabled
    )
    $dropped = @()
    $changed = $true
    $guard = 0
    while ($changed) {
        $changed = $false
        if (++$guard -gt 50) { throw "의존성 연쇄가 끝나지 않는다." }
        foreach ($m in $Manifest.mods) {
            if (-not $Enabled.Contains($m.packageId)) { continue }
            $missing = $null
            foreach ($r in @($m.requires) + @($m.onlyIf)) {
                if ($r -and -not $Enabled.Contains($r)) { $missing = $r; break }
            }
            if ($missing) {
                [void]$Enabled.Remove($m.packageId)
                $dropped += [pscustomobject]@{ packageId = $m.packageId; name = $m.name; because = $missing }
                $changed = $true
            }
        }
    }
    return [pscustomobject]@{ Enabled = $Enabled; Dropped = $dropped }
}

<#
  기본 선택 집합. defaultEnabled 가 false 인 것과 obtainable 이 false 인 것은 뺀다.
#>
function Get-DefaultSelection {
    param([Parameter(Mandatory)]$Manifest)
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($m in $Manifest.mods) {
        if ($m.PSObject.Properties.Name -contains 'defaultEnabled' -and -not $m.defaultEnabled) { continue }
        if ($m.PSObject.Properties.Name -contains 'obtainable'    -and -not $m.obtainable)    { continue }
        [void]$set.Add($m.packageId)
    }
    return $set
}

<#
  ModsConfig.xml 본문을 만든다.

  ⚠ 형식을 바꾸지 마라. 실제 파일과 바이트 단위로 같아야 한다.
    · 줄바꿈 CRLF, 마지막 줄만 LF 없음
    · 들여쓰기 공백 2칸
    · packageId 는 전부 소문자
    · BOM 없음
#>
function New-ModsConfigXml {
    param(
        [Parameter(Mandatory)]$Manifest,
        [Parameter(Mandatory)][System.Collections.Generic.HashSet[string]]$Enabled,
        [Parameter(Mandatory)][string]$GameVersion,
        [string[]]$KnownExpansions = @(
            "ludeon.rimworld.royalty", "ludeon.rimworld.ideology",
            "ludeon.rimworld.biotech", "ludeon.rimworld.anomaly",
            "ludeon.rimworld.odyssey")
    )
    # 갈래 전용 모드(variantExtras)도 대상에 넣는다.
    # 그것들은 자기가 밀어낸 모드의 order 를 물려받으므로 같은 칸에 들어간다.
    $all = @($Manifest.mods) + @($Manifest.variantExtras | Where-Object { $_ })
    $ordered = $all |
        Where-Object { $Enabled.Contains($_.packageId) -and [int]$_.order -gt 0 } |
        Sort-Object { [int]$_.order }, { $_.packageId }

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("<?xml version=`"1.0`" encoding=`"utf-8`"?>`r`n")
    [void]$sb.Append("<ModsConfigData>`r`n")
    [void]$sb.Append("  <version>$GameVersion</version>`r`n")
    [void]$sb.Append("  <activeMods>`r`n")
    foreach ($m in $ordered) {
        [void]$sb.Append("    <li>$($m.packageId.ToLower())</li>`r`n")
    }
    [void]$sb.Append("  </activeMods>`r`n")
    [void]$sb.Append("  <knownExpansions>`r`n")
    foreach ($e in $KnownExpansions) {
        [void]$sb.Append("    <li>$e</li>`r`n")
    }
    [void]$sb.Append("  </knownExpansions>`r`n")
    [void]$sb.Append("</ModsConfigData>")
    return $sb.ToString()
}

function Save-ModsConfig {
    param([Parameter(Mandatory)][string]$Text, [Parameter(Mandatory)][string]$Path)
    $dir = Split-Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false)))
}

# 실제 ModsConfig.xml 을 바꾸기 전에는 반드시 날짜 백업을 만든다(저장소 규약).
function Backup-ModsConfig {
    param([Parameter(Mandatory)][string]$Path, [string]$Tag = "installer")
    if (-not (Test-Path $Path)) { return $null }
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss-fffffff")
    $dest = Join-Path (Split-Path $Path -Parent) "ModsConfig.backup-$stamp-$Tag.xml"
    Copy-Item -LiteralPath $Path -Destination $dest -ErrorAction Stop
    return $dest
}

function Get-GameVersionFromConfig {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) { return $null }
    $xml = Read-XmlUtf8 $Path
    if (-not $xml) { return $null }
    return [string]$xml.ModsConfigData.version
}

function Get-PresetConfiguration {
    param([string]$RepoRoot, [string]$Name, [string]$Adult, [string]$Hygiene)
    $saved = Read-JsonUtf8 (Join-Path $RepoRoot 'installer\selection.json')
    if (-not $Name) { $Name = if ($saved.preset) { [string]$saved.preset } else { 'standard' } }
    if (-not $Adult) { $Adult = if ($saved.adult) { [string]$saved.adult } else { 'off' } }
    if ($Adult -notin @('off', 'on')) { throw '성인 요소 선택 값이 잘못됐다.' }
    $doc = Read-JsonUtf8 (Join-Path $RepoRoot 'site\presets.json')
    $preset = $doc.presets | Where-Object { $_.id -eq $Name } | Select-Object -First 1
    if (-not $preset) { throw "프리셋을 찾지 못했다: $Name" }
    if ($Hygiene) { $preset.hygiene = $Hygiene }
    return [pscustomobject]@{ Preset=$preset; Adult=$Adult; Hygiene=$preset.hygiene }
}
function Resolve-Preset {
    param($Manifest, $Preset, [string]$Adult = "off")

    # Get-DefaultSelection 의 HashSet 은 반환하면서 배열로 풀린다.
    # 설치기 쪽은 타입 지정 파라미터가 다시 조여 주지만 여기서는 직접 손대므로
    # 우리가 다시 HashSet 으로 만들어 둔다.
    $enabled = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($id in @(Get-DefaultSelection -Manifest $Manifest)) { [void]$enabled.Add($id) }

    foreach ($g in @($Preset.excludeGroups)) {
        if (-not $g) { continue }
        foreach ($m in $Manifest.mods) {
            if ($m.group -eq $g -and -not $m.required) { [void]$enabled.Remove($m.packageId) }
        }
    }
    foreach ($id in @($Preset.excludeMods)) {
        if ($id) { [void]$enabled.Remove($id) }
    }

    # 설치기와 같은 순서로 부른다. 여기서만 다른 규칙을 만들면 사이트가 거짓말을 한다.
    $enabled = Resolve-Variants        -Manifest $Manifest `
                   -Selections @{ hygiene = $Preset.hygiene; adult = $Adult } -Enabled $enabled
    $enabled = Add-RequiredDependencies -Manifest $Manifest -Enabled $enabled
    $res     = Remove-Dependents        -Manifest $Manifest -Enabled $enabled
    $enabled = $res.Enabled
    $dropped = @($res.Dropped)

    $all = @($Manifest.mods) + @($Manifest.variantExtras | Where-Object { $_ })
    $ordered = @($all | Where-Object { $enabled.Contains($_.packageId) -and [int]$_.order -gt 0 } |
                 Sort-Object { [int]$_.order }, { $_.packageId })

    return [pscustomobject]@{
        Preset  = $Preset
        Enabled = $enabled
        Ordered = $ordered
        Count   = $ordered.Count
        Ours    = @($ordered | Where-Object { $_.packageId -like 'codex.*' }).Count
        Dropped = $dropped
    }
}
