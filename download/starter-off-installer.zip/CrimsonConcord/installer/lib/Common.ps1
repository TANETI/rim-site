﻿<#
.SYNOPSIS
  설치기 공용 도우미. 경로 탐지, 인코딩, 로그.

.DESCRIPTION
  이 파일은 dot-source 로만 쓴다.  . "$PSScriptRoot\lib\Common.ps1"

  ── 인코딩 함정 두 개 (이 프로젝트에서 실제로 밟았다) ──────────────
  1. PowerShell 5.1 은 스크립트 파일을 시스템 ANSI 로 읽는다. 한글이 든
     .ps1 은 **UTF-8 BOM** 으로 저장해야 파싱이 깨지지 않는다.
  2. Get-Content 의 기본 인코딩도 ANSI 다. 한글·일본어가 든 About.xml 을
     그대로 읽으면 망가진다. Read-XmlUtf8 을 쓴다.
#>

# 콘솔 출력이 물음표로 깨지는 것을 막는다.
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch { }

$script:CcLogPath = $null

function Set-CcLog {
    param([string]$Path)
    $script:CcLogPath = $Path
    $dir = Split-Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
}

function Write-Step   { param([string]$Text) Write-CcLine "==> $Text" Cyan }
function Write-Ok     { param([string]$Text) Write-CcLine "  OK   $Text" Green }
function Write-Warn   { param([string]$Text) Write-CcLine "  주의 $Text" Yellow }
function Write-Fail   { param([string]$Text) Write-CcLine "  실패 $Text" Red }
function Write-Info   { param([string]$Text) Write-CcLine "       $Text" Gray }

# UI 가 로그를 자기 창에도 받아 가려고 걸어 두는 자리.
# 콘솔로 쓸 때는 비어 있다.
$script:CcSink = $null
function Set-CcSink { param([scriptblock]$Sink) $script:CcSink = $Sink }

function Write-CcLine {
    param([string]$Text, [string]$Color = "White")
    if ($script:CcSink) {
        try { & $script:CcSink $Text $Color } catch { }
    } else {
        Write-Host $Text -ForegroundColor $Color
    }
    if ($script:CcLogPath) {
        $stamp = (Get-Date).ToString("HH:mm:ss")
        Add-Content -Path $script:CcLogPath -Value "$stamp $Text" -Encoding UTF8
    }
}

# About.xml 등 외부 XML 은 반드시 이걸로 읽는다.
function Read-XmlUtf8 {
    param([string]$Path)
    try { return [xml][System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8) }
    catch { return $null }
}

function Read-JsonUtf8 {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $null }
    $raw = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    # JSON 에 주석을 허용한다(jsonc). 문자열 안의 // 는 건드리지 않도록 줄 단위로 본다.
    $clean = ($raw -split "`r?`n" | ForEach-Object {
        if ($_ -match '^\s*//') { '' } else { $_ }
    }) -join "`n"
    return $clean | ConvertFrom-Json
}

# ConvertTo-Json 은 5.1 에서 한글을 \uXXXX 로 이스케이프한다. 읽을 수 있게 되돌린다.
function Write-JsonUtf8 {
    param([Parameter(Mandatory)]$Object, [Parameter(Mandatory)][string]$Path, [int]$Depth = 12)
    $json = $Object | ConvertTo-Json -Depth $Depth
    $json = [System.Text.RegularExpressions.Regex]::Replace(
        $json, '\\u([0-9a-fA-F]{4})',
        { param($m) [char][Convert]::ToInt32($m.Groups[1].Value, 16) })
    $dir = Split-Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    # BOM 없는 UTF-8. JSON 은 BOM 이 없는 편이 다른 도구와 잘 맞는다.
    [System.IO.File]::WriteAllText($Path, $json, (New-Object System.Text.UTF8Encoding($false)))
}

<#
  RimWorld 설치 경로를 찾는다. 컴퓨터마다 다르므로 고정하지 않는다.
  기본 후보 → Steam 라이브러리 VDF 순으로 훑는다.
#>
function Find-RimWorldPath {
    $candidates = @(
        "C:\Program Files (x86)\Steam\steamapps\common\RimWorld",
        "C:\Program Files\Steam\steamapps\common\RimWorld",
        "D:\Steam\steamapps\common\RimWorld",
        "D:\SteamLibrary\steamapps\common\RimWorld",
        "E:\SteamLibrary\steamapps\common\RimWorld"
    )
    foreach ($vdf in @("C:\Program Files (x86)\Steam\steamapps\libraryfolders.vdf",
                       "C:\Program Files\Steam\steamapps\libraryfolders.vdf")) {
        if (-not (Test-Path $vdf)) { continue }
        $text = [System.IO.File]::ReadAllText($vdf)
        foreach ($m in [regex]::Matches($text, '"path"\s*"([^"]+)"')) {
            $p = $m.Groups[1].Value -replace '\\\\', '\'
            $candidates += (Join-Path $p "steamapps\common\RimWorld")
        }
    }
    foreach ($c in $candidates) {
        if (Test-Path (Join-Path $c "RimWorldWin64.exe")) { return $c }
    }
    return $null
}

function Get-WorkshopPath {
    param([Parameter(Mandatory)][string]$RimWorldPath)
    $steamApps = Split-Path (Split-Path $RimWorldPath -Parent) -Parent
    $p = Join-Path $steamApps "workshop\content\294100"
    if (Test-Path $p) { return $p }
    return $null
}

function Get-ConfigFolder {
    Join-Path $env:LOCALAPPDATA "..\LocalLow\Ludeon Studios\RimWorld by Ludeon Studios\Config" |
        ForEach-Object { [System.IO.Path]::GetFullPath($_) }
}

<#
  OneDrive 아래 설치는 이 프로젝트의 금지 사항이다.
  파일 동기화가 게임 파일을 물고 있어 저장·로드가 깨진다.
#>
function Test-OneDrivePath {
    param([string]$Path)
    if (-not $Path) { return $false }
    return ($Path -match '(?i)onedrive')
}

# 활성 packageId → 실제 폴더. 한 번 훑고 해시로 돌려준다.
function Get-ModFolderIndex {
    param(
        [Parameter(Mandatory)][string]$RimWorldPath,
        [string[]]$ExtraRoots = @()
    )
    $roots = @()
    $ws = Get-WorkshopPath -RimWorldPath $RimWorldPath
    if ($ws) { $roots += $ws }
    $roots += (Join-Path $RimWorldPath "Mods")
    $roots += $ExtraRoots
    $roots = $roots | Where-Object { $_ -and (Test-Path $_) }

    $index = @{}
    foreach ($root in $roots) {
        foreach ($dir in Get-ChildItem $root -Directory -ErrorAction SilentlyContinue) {
            $about = Join-Path $dir.FullName "About\About.xml"
            if (-not (Test-Path $about)) { continue }
            $xml = Read-XmlUtf8 $about
            if (-not $xml) { continue }
            $id = [string]$xml.ModMetaData.packageId
            if (-not $id) { continue }
            $id = $id.Trim().ToLower()
            if (-not $index.ContainsKey($id)) {
                $index[$id] = [pscustomobject]@{
                    PackageId = $id
                    Folder    = $dir.FullName
                    Root      = $root
                    About     = $xml
                }
            }
        }
    }
    return $index
}
