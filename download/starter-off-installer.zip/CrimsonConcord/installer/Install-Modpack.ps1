﻿<#
.SYNOPSIS
  진조이니라! 모드팩 설치기.

.DESCRIPTION
  ── 이 도구가 하는 일 셋 (2026-09-01 범위 확정) ────────────────────

    1. 우리가 만든 모드를 설치·갱신한다     (자작 20개)
    2. 배열을 정리한다                      (ModsConfig.xml 생성)
    3. RimSort 를 받아 준다                 (todds 가 그 안에 있어 DDS 변환까지)

  ── 하지 않는 일 ──────────────────────────────────────────────────

  **Workshop 모드를 대신 받지 않는다.** 각자 Steam 에서 구독한다.
  SteamCMD 자동 다운로드는 2026-09-01 에 걷어냈다. 한 번도 실전에서 돌지
  않은 기능이었고, 친구들이 직접 받겠다고 해서 필요가 없어졌다.

  대신 **무엇이 없는지 목록과 워크샵 링크를 뽑아 준다.**
  installer\missing-mods.txt 에 저장하므로 그것만 보고 구독하면 된다.

.EXAMPLE
  # 무엇을 할지 보기만 한다. 아무것도 바꾸지 않는다
  .\installer\Install-Modpack.ps1 -WhatIf

  # 자작 모드를 설치하고 배열을 만든다 (기본 동작)
  .\installer\Install-Modpack.ps1 -Apply

  # 배열만. 자작 모드는 건드리지 않는다
  .\installer\Install-Modpack.ps1 -Apply -SkipLocalMods

  # RimSort 를 받고 DDS 변환까지
  .\installer\Install-Modpack.ps1 -Apply -WithRimSort -WithDds
#>
[CmdletBinding()]
param(
    [string]$RimWorldPath,
    [string]$Preset,
    [switch]$ToolsOnly,
    [ValidateSet("none", "lite", "full")]
    [string]$Hygiene,
    # 성인 요소. 프리셋과 별개 축이라 따로 받는다(2026-09-01 결정).
    # 안 주면 매니페스트의 기본값 off 를 쓴다.
    [ValidateSet("off", "on")]
    [string]$Adult,
    [switch]$Interactive,
    [switch]$Apply,
    # 이 설치기는 -Apply 가 있어야 실제로 쓴다. 즉 아무것도 안 붙이면 이미 미리보기다.
    # 그런데 문서와 사이트가 -WhatIf 를 안내하고 있었고 그런 파라미터가 없어
    # 바로 오류가 났다. PowerShell 사용자가 기대하는 철자이므로 받아 준다.
    # -Apply 와 함께 와도 미리보기가 이긴다.
    [switch]$WhatIf,
    [switch]$WithRimSort,
    [switch]$WithDds,
    # 자작 모드 설치·갱신은 이 도구의 본업이라 -Apply 면 기본으로 한다.
    # 배열만 만들고 싶으면 -SkipLocalMods.
    [switch]$SkipLocalMods,
    [string]$UpdateSource,
    # 갱신 전 설치본 백업을 끈다. 되돌릴 길이 없어지므로 기본값은 켜짐이다.
    [switch]$NoBackup,
    [string]$RimSortRoot = (Join-Path $env:LOCALAPPDATA 'RimSort')
)

$ErrorActionPreference = "Stop"
if ($WhatIf) { $Apply = $false }
$repoRoot = Split-Path $PSScriptRoot -Parent
. (Join-Path $repoRoot "installer\lib\Common.ps1")
. (Join-Path $repoRoot "installer\lib\ModsConfig.ps1")
. (Join-Path $repoRoot "installer\lib\RimSort.ps1")
. (Join-Path $repoRoot "installer\lib\Todds.ps1")
. (Join-Path $repoRoot "installer\lib\Updater.ps1")

Set-CcLog (Join-Path $repoRoot "logs\installer-$((Get-Date).ToString('yyyyMMdd-HHmm')).log")

Write-Step "진조이니라! 모드팩 설치기"

# ── 1. 매니페스트 ─────────────────────────────────────────────────
$manifestPath = Join-Path $repoRoot "installer\modpack.manifest.json"
if (-not (Test-Path $manifestPath)) { throw "매니페스트가 없다. scripts\build-manifest.ps1 을 먼저 돌려라." }
$manifest = Read-JsonUtf8 $manifestPath
$presetConfig = Get-PresetConfiguration -RepoRoot $repoRoot -Name $Preset -Adult $Adult -Hygiene $Hygiene
if (-not $Interactive) {
    $Hygiene = $presetConfig.Hygiene
    $Adult = $presetConfig.Adult
}
Write-Info "$($manifest.packName) / $($manifest.packVersion) / 모드 $($manifest.mods.Count)개"

# ── 2. 경로 ───────────────────────────────────────────────────────
if (-not $RimWorldPath) { $RimWorldPath = Find-RimWorldPath }
if (-not $RimWorldPath) { throw "RimWorld 설치 경로를 찾지 못했다. -RimWorldPath 로 지정해라." }
Write-Ok "RimWorld : $RimWorldPath"

if (Test-OneDrivePath $RimWorldPath) {
    Write-Fail "RimWorld 가 OneDrive 아래에 있다. 동기화가 게임 파일을 물어 저장·로드가 깨진다."
    throw "OneDrive 경로에는 설치하지 않는다."
}

$configFolder = Get-ConfigFolder
$liveConfig   = Join-Path $configFolder "ModsConfig.xml"
Write-Info "설정 폴더 : $configFolder"

# ── 3. DLC ────────────────────────────────────────────────────────
Write-Step "DLC 확인"
$missingDlc = @()
foreach ($dlc in $manifest.requiredDlc) {
    if (Test-Path (Join-Path $RimWorldPath "Data\$dlc")) { Write-Ok $dlc }
    else { Write-Fail "$dlc 없음"; $missingDlc += $dlc }
}
if ($missingDlc.Count) {
    throw "필요한 DLC 가 없다: $($missingDlc -join ', '). 이 팩은 이 넷을 전제로 배열이 짜여 있다."
}

# ── 4. 구성 선택 ──────────────────────────────────────────────────
Write-Step "구성 선택"
$selections = @{}
foreach ($v in $manifest.variants) {
    $chosen = $null
    if ($v.id -eq "hygiene" -and $Hygiene) { $chosen = $Hygiene }
    if ($v.id -eq "adult"   -and $Adult)   { $chosen = $Adult }

    if (-not $chosen -and $Interactive) {
        Write-Info ""
        Write-Info $v.prompt
        $i = 0
        foreach ($opt in $v.options) {
            $i++
            $mark = if ($opt.id -eq $v.default) { " (기본값)" } else { "" }
            Write-Info ("  {0}. {1}{2} — {3}" -f $i, $opt.label, $mark, $opt.summary)
            foreach ($d in @($opt.detail)) { Write-Info "       $d" }
        }
        $ans = Read-Host "번호 (엔터 = 기본값)"
        if ($ans -and $ans -match '^\d+$' -and [int]$ans -ge 1 -and [int]$ans -le $v.options.Count) {
            $chosen = $v.options[[int]$ans - 1].id
        }
    }

    if (-not $chosen) { $chosen = $v.default }
    $selections[$v.id] = $chosen

    $opt = $v.options | Where-Object { $_.id -eq $chosen } | Select-Object -First 1
    Write-Ok "$($v.label) : $($opt.label)"
    if ($opt.PSObject.Properties.Name -contains 'verified' -and -not $opt.verified) {
        Write-Warn "이 갈래는 아직 부팅 검증을 하지 않았다. 문제가 생기면 기본값($($v.default))으로 돌려라"
        foreach ($d in @($opt.detail)) { Write-Info "  $d" }
    }
}

# ── 5. 집합 확정 ──────────────────────────────────────────────────
$presetConfig.Preset.hygiene = $selections.hygiene
$res = Resolve-Preset -Manifest $manifest -Preset $presetConfig.Preset -Adult $selections.adult
$enabled = $res.Enabled

foreach ($d in $res.Dropped) {
    Write-Warn "$($d.name) 는 $($d.because) 가 빠져서 함께 뺐다"
}

$version = Get-GameVersionFromConfig -Path $liveConfig
if (-not $version) { $version = Get-GameVersionFromConfig -Path (Join-Path $repoRoot "config\ModsConfig.xml") }
if (-not $version) { $version = [string]$manifest.rimworldVersion }
$xml = New-ModsConfigXml -Manifest $manifest -Enabled $enabled -GameVersion $version

$allEntries = @($manifest.mods) + @($manifest.variantExtras | Where-Object { $_ })
$activeCount = @($allEntries | Where-Object { $enabled.Contains($_.packageId) -and [int]$_.order -gt 0 }).Count
Write-Ok "활성 $activeCount 개"

# ── 5-1. 자작 모드 설치·갱신 ─────────────────────────────────────
#
# 이 도구의 본업이라 -Apply 면 기본으로 한다.
# Update-LocalMods 는 설치본에 없는 모드를 "새로 설치" 로 처리하므로
# 처음 까는 컴퓨터에서도 같은 경로가 그대로 쓰인다.
#
# 없는 모드 목록보다 **먼저** 해야 한다. 안 그러면 우리가 곧 깔 20개까지
# "없는 모드" 로 세어 친구에게 구독하라고 시킨다.
if (-not $SkipLocalMods -and -not $ToolsOnly) {
    Write-Step "자작 모드 설치·갱신"
    $src = if ($UpdateSource) { $UpdateSource } else { "local:$repoRoot" }
    $s   = Get-UpdateSource -Source $src
    $cmp = Compare-LocalMods -SourceLocalMods $s.LocalMods -RimWorldPath $RimWorldPath
    foreach ($row in $cmp) {
        if ($row.State -eq "최신") { Write-Info "  최신 : $($row.Name)" }
        else { Write-Warn "$($row.State) : $($row.Name)" }
    }
    if ($s.IndexPath) { Write-Info "무결성 색인 : $($s.IndexPath)" }
    if ($Apply) {
        Update-LocalMods -Comparison $cmp `
            -IndexPath $s.IndexPath -SourceLocalMods $s.LocalMods `
            -NoBackup:$NoBackup | Out-Null
    }
    else { Write-Info "-Apply 가 없어 대조만 했다. 덮어쓰지 않았다" }
}

# ── 5-2. 없는 모드 목록 ──────────────────────────────────────────
#
# 이 도구는 Workshop 모드를 받아 주지 않는다. 대신 **무엇이 없는지**를
# 링크와 함께 파일로 뽑아 준다. 그것만 보고 구독하면 된다.
#
# ExtraRoots 로 저장소의 local-mods 도 본다. -WhatIf 로 돌려 아직 설치본에
# 없을 때도 우리 모드를 "없는 것" 으로 세지 않기 위해서다.
$index = Get-ModFolderIndex -RimWorldPath $RimWorldPath -ExtraRoots @(Join-Path $repoRoot "local-mods")
$absent = @()
foreach ($m in $allEntries) {
    if (-not $enabled.Contains($m.packageId)) { continue }
    if ($m.source -eq 'dlc') { continue }
    if (-not $index.ContainsKey($m.packageId)) { $absent += $m }
}

$missingFile = Join-Path $PSScriptRoot "missing-mods.txt"
if ($absent.Count) {
    Write-Step "아직 없는 모드 $($absent.Count)개"
    Write-Warn "이대로 배열에 넣으면 모드 목록에 빨간 느낌표가 뜬다. 구독한 뒤 다시 돌려라"

    $lines = @(
        "진조이니라! 모드팩 — 아직 구독하지 않은 모드 $($absent.Count)개",
        "생성 $((Get-Date).ToString('yyyy-MM-dd HH:mm'))",
        "",
        "Steam 에서 아래를 구독한 뒤 설치기를 다시 돌리면 된다.",
        "다 받으면 이 파일은 없는 모드 0개로 다시 쓰인다.",
        ""
    )
    foreach ($m in $absent) {
        Write-Info "  $($m.name)"
        $lines += "- $($m.name)  [$($m.packageId)]"
        if ($m.workshopId) { $lines += "  https://steamcommunity.com/sharedfiles/filedetails/?id=$($m.workshopId)" }
        else { $lines += "  (워크샵 ID 를 모른다. 이름으로 찾아야 한다)" }
        $lines += ""
    }
    [System.IO.File]::WriteAllLines($missingFile, $lines, (New-Object System.Text.UTF8Encoding($true)))
    Write-Ok "링크를 파일로 뽑아 뒀다: $missingFile"
} else {
    Write-Ok "배열에 필요한 모드가 전부 있다"
    if (Test-Path $missingFile) { Remove-Item $missingFile -Force -ErrorAction SilentlyContinue }
}

# ── 6. 적용 ───────────────────────────────────────────────────────
if (-not $Apply) {
    Write-Step "미리보기만 했다. 실제로 쓰려면 -Apply 를 붙여라"
    $preview = Join-Path $repoRoot "installer\ModsConfig.preview.xml"
    Save-ModsConfig -Text $xml -Path $preview
    Write-Ok "생성 결과를 여기 뒀다: $preview"
} elseif (-not $ToolsOnly) {
    Write-Step "ModsConfig.xml 적용"
    $backup = Backup-ModsConfig -Path $liveConfig -Tag "installer"
    if ($backup) { Write-Ok "백업 : $backup" } else { Write-Warn "기존 ModsConfig 가 없어 백업을 만들지 않았다" }
    Save-ModsConfig -Text $xml -Path $liveConfig
    Write-Ok "적용 : $liveConfig"
}

# ── 7. RimSort (todds 가 이 안에 들어 있다) ───────────────────────
$rimsort = $null
if (($WithRimSort -or $WithDds) -and $Apply) {
    $rimsort = Install-RimSort -InstallRoot $RimSortRoot
} elseif ($WithRimSort -or $WithDds) {
    Write-Info "미리보기: RimSort 설치 및 DDS 변환은 -Apply를 붙였을 때만 진행한다"
}

# ── 8. DDS ────────────────────────────────────────────────────────
if ($WithDds -and $Apply) {
    $todds = if ($rimsort) { $rimsort.ToddsExe } else { Find-Todds }
    if (-not $todds) {
        Write-Fail "todds 를 찾지 못했다. -WithRimSort 로 RimSort 를 먼저 받아라 (todds 가 그 안에 있다)"
    } else {
        $targets = New-ToddsTargetList -RepoRoot $repoRoot -RimWorldPath $RimWorldPath
        Show-DdsPlan -Targets $targets -ToddsExe $todds
        $go = Read-Host "진행할까? (y/N)"
        if ($go -eq 'y') {
            if (Invoke-DdsConversion -ToddsExe $todds -TargetFile $targets.Path -OverwriteNew) {
                Invoke-DdsPrune -RepoRoot $repoRoot | Out-Null
            }
        } else {
            Write-Info "DDS 변환을 건너뛴다. 나중에 하려면 같은 명령을 다시 돌리면 된다"
        }
    }
}

# ── 9. 마무리 ─────────────────────────────────────────────────────
Write-Step "다음에 할 것"
Write-Info "1. RimWorld 를 켜고 모드 목록에 빨간 느낌표가 없는지 본다"
Write-Info "2. Player.log 를 다음 넷으로 훑는다"
Write-Info "     Exception | Config error | Could not resolve cross-reference | XML error"
if ($rimsort) { Write-Info "3. 순서를 직접 손보려면 RimSort 를 쓴다: $($rimsort.Exe)" }
Write-Ok "끝"
