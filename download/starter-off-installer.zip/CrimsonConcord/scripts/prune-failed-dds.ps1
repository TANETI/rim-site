﻿<#
.SYNOPSIS
  Player.log에서 Image Opt가 읽지 못한 DDS를 찾아 지운다.

.DESCRIPTION
  todds가 만든 DDS 중 일부는 GPU가 텍스처로 만들지 못한다.
  대부분 BC7이 요구하는 "가로·세로가 4의 배수" 조건을 만족하지 않는 이미지다.
  (오류 코드 -2147024809 = E_INVALIDARG)

  이때 Image Opt는 바닐라 로더로 폴백하므로 게임은 정상 동작한다.
  다만 매 부팅마다 실패를 반복하고 로그가 지저분해지므로, 해당 DDS만 지워
  처음부터 PNG로 읽게 만든다. 원본 PNG는 그대로 있으므로 화면은 달라지지 않는다.

  todds를 다시 돌리면 지워진 DDS가 다시 생긴다.
  변환 → 부팅 → 이 스크립트 순서로 한 번 더 돌리면 된다.

.EXAMPLE
  .\scripts\prune-failed-dds.ps1
  .\scripts\prune-failed-dds.ps1 -WhatIf
  .\scripts\prune-failed-dds.ps1 -LogPath "C:\...\logs\dds-boot.log"
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$LogPath = (Join-Path $env:USERPROFILE 'AppData\LocalLow\Ludeon Studios\RimWorld by Ludeon Studios\Player.log')
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $LogPath)) { throw "로그를 찾지 못했다: $LogPath" }

$text = [System.IO.File]::ReadAllText($LogPath, [System.Text.Encoding]::UTF8)

# 실패 기록 형식이 두 가지다.
#
#  1. Image Opt가 있을 때  : [ImageOpt] load image "...\foo.dds" (경로의 백슬래시가 두 번 겹친다)
#  2. Image Opt가 없을 때  : 바닐라 Verse.ModDdsLoader가 던지고 앞줄에 absFilePath: ...\foo.dds 가 남는다
#
# 데스크탑처럼 Image Opt 없이 DDS만 쓰는 구성에서는 2번만 나온다.
# 1번만 보면 "실패한 DDS가 없다"고 잘못 판정한다.
$paths = @(
    [regex]::Matches($text, '\[ImageOpt\] load image "([^"]+\.dds)"') |
        ForEach-Object { $_.Groups[1].Value -replace '\\\\', '\' }
) + @(
    [regex]::Matches($text, '(?m)^absFilePath:\s*(.+\.dds)\s*$') |
        ForEach-Object { $_.Groups[1].Value.Trim() }
) | Sort-Object -Unique

if (-not $paths) {
    Write-Host "실패한 DDS가 없다. 정리할 것이 없다."
    return
}

Write-Host ("실패한 DDS: " + $paths.Count + "개")

$removed = 0
$missing = 0
foreach ($p in $paths) {
    if (Test-Path -LiteralPath $p) {
        if ($PSCmdlet.ShouldProcess($p, "삭제")) {
            Remove-Item -LiteralPath $p -Force
            $removed++
        }
    } else {
        $missing++
    }
}

Write-Host ("삭제: {0}   이미 없음: {1}" -f $removed, $missing)
Write-Host "원본 PNG는 건드리지 않았다. 해당 텍스처는 이제 PNG로 로드된다."
