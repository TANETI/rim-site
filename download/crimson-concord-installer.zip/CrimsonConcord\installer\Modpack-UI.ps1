﻿<#
.SYNOPSIS
  설치기 창. 콘솔판과 같은 lib 를 쓴다.

.DESCRIPTION
  콘솔로 다 되는 일이지만, 처음 하는 사람에게 인자 이름을 외우게 하고 싶지 않아 만들었다.
  화면이 하는 일은 **선택을 모아 lib 함수를 부르는 것뿐**이다.
  판단은 전부 Install-Modpack.ps1 과 같은 코드에서 한다.

  긴 작업(모드 받기, DDS 변환)이 도는 동안 창이 멈춘 것처럼 보인다.
  진행 상황은 아래 로그 칸에 계속 올라온다. 닫지 말고 기다리면 된다.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\installer\Modpack-UI.ps1
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$repoRoot = Split-Path $PSScriptRoot -Parent
. (Join-Path $repoRoot "installer\lib\Common.ps1")
. (Join-Path $repoRoot "installer\lib\ModsConfig.ps1")
. (Join-Path $repoRoot "installer\lib\RimSort.ps1")
. (Join-Path $repoRoot "installer\lib\Todds.ps1")
. (Join-Path $repoRoot "installer\lib\Updater.ps1")

Set-CcLog (Join-Path $repoRoot "logs\installer-ui-$((Get-Date).ToString('yyyyMMdd-HHmm')).log")

$manifestPath = Join-Path $repoRoot "installer\modpack.manifest.json"
if (-not (Test-Path $manifestPath)) {
    [System.Windows.Forms.MessageBox]::Show(
        "매니페스트가 없다.`n먼저 scripts\build-manifest.ps1 을 돌려라.",
        "진조이니라! 설치기", 'OK', 'Error') | Out-Null
    return
}
$manifest = Read-JsonUtf8 $manifestPath

# ── 창 ────────────────────────────────────────────────────────────
$form                 = New-Object System.Windows.Forms.Form
$form.Text            = "$($manifest.packName) 설치기"
$form.Size            = New-Object System.Drawing.Size(940, 720)
$form.StartPosition   = "CenterScreen"
$form.Font            = New-Object System.Drawing.Font("Malgun Gothic", 9)
$form.MinimumSize     = New-Object System.Drawing.Size(880, 640)

function New-Label($text, $x, $y, $w, $h, $bold) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    if ($bold) { $l.Font = New-Object System.Drawing.Font("Malgun Gothic", 9, [System.Drawing.FontStyle]::Bold) }
    $form.Controls.Add($l); return $l
}

# 경로
New-Label "RimWorld 경로" 14 14 100 20 $true | Out-Null
$txtPath = New-Object System.Windows.Forms.TextBox
$txtPath.Location = New-Object System.Drawing.Point(120, 12)
$txtPath.Size = New-Object System.Drawing.Size(660, 24)
$form.Controls.Add($txtPath)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "찾기"; $btnBrowse.Location = New-Object System.Drawing.Point(790, 11)
$btnBrowse.Size = New-Object System.Drawing.Size(120, 26)
$form.Controls.Add($btnBrowse)

$lblDlc = New-Label "" 120 40 790 20 $false

# 그룹
New-Label "넣을 것" 14 72 100 20 $true | Out-Null
$clbGroups = New-Object System.Windows.Forms.CheckedListBox
$clbGroups.Location = New-Object System.Drawing.Point(14, 96)
$clbGroups.Size = New-Object System.Drawing.Size(420, 250)
$clbGroups.CheckOnClick = $true
$form.Controls.Add($clbGroups)

$lblGroupHelp = New-Label "" 14 350 420 40 $false
$lblGroupHelp.ForeColor = [System.Drawing.Color]::DimGray

# 갈래
New-Label "위생 (Dubs Bad Hygiene)" 460 72 300 20 $true | Out-Null
$grpHygiene = New-Object System.Windows.Forms.GroupBox
$grpHygiene.Location = New-Object System.Drawing.Point(460, 94)
$grpHygiene.Size = New-Object System.Drawing.Size(450, 130)
$form.Controls.Add($grpHygiene)

$hygieneVariant = $manifest.variants | Where-Object { $_.id -eq 'hygiene' } | Select-Object -First 1
$radios = @()
if ($hygieneVariant) {
    $y = 22
    foreach ($opt in $hygieneVariant.options) {
        $r = New-Object System.Windows.Forms.RadioButton
        $r.Text = "$($opt.label) — $($opt.summary)"
        $r.Location = New-Object System.Drawing.Point(12, $y)
        $r.Size = New-Object System.Drawing.Size(425, 34)
        $r.Tag = $opt.id
        $r.Checked = ($opt.id -eq $hygieneVariant.default)
        $grpHygiene.Controls.Add($r)
        $radios += $r
        $y += 34
    }
}

$lblHygieneNote = New-Label "" 460 230 450 92 $false
$lblHygieneNote.ForeColor = [System.Drawing.Color]::FromArgb(150, 60, 20)

# 성인 요소. 프리셋·난이도와 별개 축이라 따로 둔다(2026-09-01 결정).
# 기본값은 매니페스트의 default(=off) 를 그대로 따른다.
$adultVariant = $manifest.variants | Where-Object { $_.id -eq 'adult' } | Select-Object -First 1
$chkAdult = New-Object System.Windows.Forms.CheckBox
$chkAdult.Location = New-Object System.Drawing.Point(460, 326)
$chkAdult.Size = New-Object System.Drawing.Size(450, 22)
if ($adultVariant) {
    $chkAdult.Text = "$($adultVariant.label) 포함 (진조의 정체성은 빼도 남는다)"
    $chkAdult.Checked = ($adultVariant.default -eq 'on')
} else {
    $chkAdult.Text = "성인 요소 포함"
    $chkAdult.Enabled = $false
}
$form.Controls.Add($chkAdult)

# 옵션
$chkRimSort = New-Object System.Windows.Forms.CheckBox
$chkRimSort.Text = "RimSort 도 설치 (약 200MB. todds 가 이 안에 들어 있다)"
$chkRimSort.Location = New-Object System.Drawing.Point(460, 350)
$chkRimSort.Size = New-Object System.Drawing.Size(450, 22)
$form.Controls.Add($chkRimSort)

$chkDds = New-Object System.Windows.Forms.CheckBox
$chkDds.Text = "DDS 변환까지 (디스크 +6GB, 수십 분. 부팅이 빨라진다)"
$chkDds.Location = New-Object System.Drawing.Point(460, 374)
$chkDds.Size = New-Object System.Drawing.Size(450, 22)
$form.Controls.Add($chkDds)

# 버튼
$btnPreview = New-Object System.Windows.Forms.Button
$btnPreview.Text = "미리보기"; $btnPreview.Location = New-Object System.Drawing.Point(14, 400)
$btnPreview.Size = New-Object System.Drawing.Size(130, 34)
$form.Controls.Add($btnPreview)

$btnMissing = New-Object System.Windows.Forms.Button
$btnMissing.Text = "없는 모드 목록"; $btnMissing.Location = New-Object System.Drawing.Point(152, 400)
$btnMissing.Size = New-Object System.Drawing.Size(150, 34)
$form.Controls.Add($btnMissing)

$btnUpdate = New-Object System.Windows.Forms.Button
$btnUpdate.Text = "자작 모드 설치"; $btnUpdate.Location = New-Object System.Drawing.Point(310, 400)
$btnUpdate.Size = New-Object System.Drawing.Size(150, 34)
$form.Controls.Add($btnUpdate)

$btnApply = New-Object System.Windows.Forms.Button
$btnApply.Text = "적용"; $btnApply.Location = New-Object System.Drawing.Point(760, 400)
$btnApply.Size = New-Object System.Drawing.Size(150, 34)
$btnApply.Font = New-Object System.Drawing.Font("Malgun Gothic", 9, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($btnApply)

# 로그
$log = New-Object System.Windows.Forms.RichTextBox
$log.Location = New-Object System.Drawing.Point(14, 444)
$log.Size = New-Object System.Drawing.Size(896, 222)
$log.ReadOnly = $true
$log.BackColor = [System.Drawing.Color]::FromArgb(28, 24, 26)
$log.Font = New-Object System.Drawing.Font("Consolas", 9)
$log.Anchor = "Top,Bottom,Left,Right"
$form.Controls.Add($log)

# ── 로그 연결 ─────────────────────────────────────────────────────
$colorMap = @{
    Cyan = [System.Drawing.Color]::FromArgb(120, 200, 230)
    Green = [System.Drawing.Color]::FromArgb(120, 210, 150)
    Yellow = [System.Drawing.Color]::FromArgb(230, 195, 110)
    Red = [System.Drawing.Color]::FromArgb(235, 130, 110)
    Gray = [System.Drawing.Color]::FromArgb(165, 158, 160)
    White = [System.Drawing.Color]::FromArgb(225, 220, 220)
}
Set-CcSink {
    param($Text, $Color)
    $c = if ($colorMap.ContainsKey($Color)) { $colorMap[$Color] } else { $colorMap.White }
    $log.SelectionStart = $log.TextLength
    $log.SelectionColor = $c
    $log.AppendText("$Text`r`n")
    $log.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Set-Busy([bool]$busy) {
    foreach ($b in @($btnPreview, $btnMissing, $btnUpdate, $btnApply, $btnBrowse)) { $b.Enabled = -not $busy }
    $form.Cursor = if ($busy) { 'WaitCursor' } else { 'Default' }
    [System.Windows.Forms.Application]::DoEvents()
}

# ── 상태 ──────────────────────────────────────────────────────────
function Get-SelectedHygiene {
    foreach ($r in $radios) { if ($r.Checked) { return [string]$r.Tag } }
    return $hygieneVariant.default
}

function Get-SelectedGroups {
    $ids = @()
    for ($i = 0; $i -lt $clbGroups.Items.Count; $i++) {
        if ($clbGroups.GetItemChecked($i)) { $ids += [string]$clbGroups.Items[$i].Tag }
    }
    return $ids
}

function Build-Selection {
    $groups = Get-SelectedGroups
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    $all = @($manifest.mods)
    foreach ($m in $all) {
        if ($m.PSObject.Properties.Name -contains 'defaultEnabled' -and -not $m.defaultEnabled) { continue }
        if ($m.PSObject.Properties.Name -contains 'obtainable'    -and -not $m.obtainable)    { continue }
        if ($m.required) { [void]$set.Add($m.packageId); continue }
        if ($groups -contains $m.group) { [void]$set.Add($m.packageId) }
    }
    $set = Resolve-Variants -Manifest $manifest -Enabled $set -Selections @{
        hygiene = (Get-SelectedHygiene)
        adult   = $(if ($chkAdult.Checked) { 'on' } else { 'off' })
    }
    $set = Add-RequiredDependencies -Manifest $manifest -Enabled $set
    $res = Remove-Dependents -Manifest $manifest -Enabled $set
    foreach ($d in $res.Dropped) { Write-Warn "$($d.name) 는 $($d.because) 가 빠져서 함께 뺐다" }
    return $res.Enabled
}

function Get-RimWorld { return $txtPath.Text.Trim() }

function Refresh-Dlc {
    $p = Get-RimWorld
    if (-not $p -or -not (Test-Path $p)) { $lblDlc.Text = "경로를 찾지 못했다"; $lblDlc.ForeColor = [System.Drawing.Color]::Firebrick; return }
    if (Test-OneDrivePath $p) {
        $lblDlc.Text = "⚠ OneDrive 아래다. 동기화가 게임 파일을 물어 저장·로드가 깨진다"
        $lblDlc.ForeColor = [System.Drawing.Color]::Firebrick; return
    }
    $missing = @($manifest.requiredDlc | Where-Object { -not (Test-Path (Join-Path $p "Data\$_")) })
    if ($missing.Count) {
        $lblDlc.Text = "DLC 없음: $($missing -join ', ')  — 이 팩은 넷을 전제로 배열이 짜여 있다"
        $lblDlc.ForeColor = [System.Drawing.Color]::Firebrick
    } else {
        $lblDlc.Text = "DLC 4종 확인됨"
        $lblDlc.ForeColor = [System.Drawing.Color]::SeaGreen
    }
}

function Refresh-Summary {
    $set = Build-Selection
    $all = @($manifest.mods) + @($manifest.variantExtras | Where-Object { $_ })
    $n = @($all | Where-Object { $set.Contains($_.packageId) -and [int]$_.order -gt 0 }).Count
    $btnApply.Text = "적용 ($n개)"

    $opt = $hygieneVariant.options | Where-Object { $_.id -eq (Get-SelectedHygiene) } | Select-Object -First 1
    if ($opt -and ($opt.PSObject.Properties.Name -contains 'verified') -and -not $opt.verified) {
        $lblHygieneNote.Text = "⚠ 이 갈래는 아직 부팅 검증 전이다.`r`n" + (@($opt.detail) -join "`r`n")
    } elseif ($opt) {
        $lblHygieneNote.Text = (@($opt.detail) -join "`r`n")
        $lblHygieneNote.ForeColor = [System.Drawing.Color]::DimGray
    }
    if ($opt -and ($opt.PSObject.Properties.Name -contains 'verified') -and -not $opt.verified) {
        $lblHygieneNote.ForeColor = [System.Drawing.Color]::FromArgb(150, 60, 20)
    }
}

# ── 그룹 목록 채우기 ──────────────────────────────────────────────
$counts = @{}
foreach ($m in $manifest.mods) {
    if (-not $counts.ContainsKey($m.group)) { $counts[$m.group] = 0 }
    $counts[$m.group]++
}
foreach ($g in $manifest.groups) {
    $c = if ($counts.ContainsKey($g.id)) { $counts[$g.id] } else { 0 }
    if ($c -eq 0) { continue }
    $item = New-Object psobject -Property @{ Tag = $g.id }
    $label = "$($g.label)  ($c개)"
    if ($g.required) { $label += "  — 해제 불가" }
    $item | Add-Member -MemberType ScriptMethod -Name ToString -Value { $this.Label }.GetNewClosure() -Force
    $item | Add-Member -MemberType NoteProperty -Name Label -Value $label -Force
    [void]$clbGroups.Items.Add($item, $true)
}
$lblGroupHelp.Text = "필수 기반은 꺼도 자동으로 다시 켜진다. 어떤 모드가 다른 모드를 요구하면 함께 따라 켜지거나 꺼진다."

# ── 이벤트 ────────────────────────────────────────────────────────
$btnBrowse.Add_Click({
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = "RimWorld 설치 폴더 (RimWorldWin64.exe 가 있는 곳)"
    if ($d.ShowDialog() -eq 'OK') { $txtPath.Text = $d.SelectedPath; Refresh-Dlc }
})
$txtPath.Add_TextChanged({ Refresh-Dlc })
$clbGroups.Add_ItemCheck({
    # ItemCheck 는 반영 전에 온다. 한 박자 뒤에 다시 센다.
    $form.BeginInvoke([Action]{ Refresh-Summary }) | Out-Null
})
foreach ($r in $radios) { $r.Add_CheckedChanged({ Refresh-Summary }) }
$chkAdult.Add_CheckedChanged({ Refresh-Summary })

$btnPreview.Add_Click({
    Set-Busy $true
    try {
        Write-Step "미리보기"
        $set = Build-Selection
        $live = Join-Path (Get-ConfigFolder) "ModsConfig.xml"
        $ver = Get-GameVersionFromConfig -Path $live
        if (-not $ver) { $ver = Get-GameVersionFromConfig -Path (Join-Path $repoRoot "config\ModsConfig.xml") }
        $xml = New-ModsConfigXml -Manifest $manifest -Enabled $set -GameVersion $ver
        $out = Join-Path $repoRoot "installer\ModsConfig.preview.xml"
        Save-ModsConfig -Text $xml -Path $out
        Write-Ok "아무것도 바꾸지 않았다. 결과만 여기 뒀다:"
        Write-Info $out

        $index = Get-ModFolderIndex -RimWorldPath (Get-RimWorld) -ExtraRoots @(Join-Path $repoRoot "local-mods")
        $all = @($manifest.mods) + @($manifest.variantExtras | Where-Object { $_ })
        $absent = @($all | Where-Object { $set.Contains($_.packageId) -and $_.source -ne 'dlc' -and -not $index.ContainsKey($_.packageId) })
        if ($absent.Count) { Write-Warn "이 컴퓨터에 없는 모드 $($absent.Count)개 — 아래 '없는 모드 목록' 을 눌러 링크를 뽑아라" }
        else { Write-Ok "필요한 모드가 전부 있다" }
    } catch { Write-Fail $_.Exception.Message } finally { Set-Busy $false }
})

# 없는 모드를 받아 주지 않는다(2026-09-01 범위 확정). 목록과 링크만 뽑아 준다.
$btnMissing.Add_Click({
    Set-Busy $true
    try {
        Write-Step "아직 없는 모드"
        $set = Build-Selection
        $index = Get-ModFolderIndex -RimWorldPath (Get-RimWorld) -ExtraRoots @(Join-Path $repoRoot "local-mods")
        $all = @($manifest.mods) + @($manifest.variantExtras | Where-Object { $_ })
        $absent = @($all | Where-Object { $set.Contains($_.packageId) -and $_.source -ne 'dlc' -and -not $index.ContainsKey($_.packageId) })
        if (-not $absent.Count) { Write-Ok "배열에 필요한 모드가 전부 있다"; return }

        $file = Join-Path $PSScriptRoot "missing-mods.txt"
        $lines = @("진조이니라! 모드팩 — 아직 구독하지 않은 모드 $($absent.Count)개",
                   "생성 $((Get-Date).ToString('yyyy-MM-dd HH:mm'))", "")
        foreach ($m in $absent) {
            Write-Warn "  $($m.name)"
            $lines += "- $($m.name)  [$($m.packageId)]"
            if ($m.workshopId) { $lines += "  https://steamcommunity.com/sharedfiles/filedetails/?id=$($m.workshopId)" }
            $lines += ""
        }
        [System.IO.File]::WriteAllLines($file, $lines, (New-Object System.Text.UTF8Encoding($true)))
        Write-Ok "링크를 파일로 뽑아 뒀다: $file"
        Start-Process notepad.exe $file
    } catch { Write-Fail $_.Exception.Message } finally { Set-Busy $false }
})

$btnUpdate.Add_Click({
    Set-Busy $true
    try {
        Write-Step "자작 모드 갱신"
        # 지금은 이 작업 사본을 원본으로 쓴다.
        # 공개 미러 저장소가 생기면 github:소유자/저장소 로 바꾸면 된다.
        $src = Get-UpdateSource -Source "local:$repoRoot"
        $cmp = Compare-LocalMods -SourceLocalMods $src.LocalMods -RimWorldPath (Get-RimWorld)
        foreach ($row in $cmp) {
            if ($row.State -eq '최신') { Write-Info "  최신 : $($row.Name)" }
            else { Write-Warn "$($row.State) : $($row.Name)" }
        }
        $changed = @($cmp | Where-Object { $_.State -ne '최신' })
        if (-not $changed.Count) { Write-Ok "갱신할 것이 없다"; return }

        $backupRoot = Get-ModBackupRoot
        $ans = [System.Windows.Forms.MessageBox]::Show(
            "$($changed.Count)개를 설치본에 덮어쓴다.`n`n" +
            (($changed | ForEach-Object { "  · $($_.Name)  [$($_.State)]" }) -join "`n") +
            "`n`n덮어쓰기 전에 기존 설치본을 통째로 복사해 둔다:`n" +
            "  $backupRoot`n`n계속할까?", "자작 모드 갱신", 'YesNo', 'Warning')
        if ($ans -ne 'Yes') { Write-Info "취소했다"; return }
        Update-LocalMods -Comparison $cmp -IndexPath $src.IndexPath `
            -SourceLocalMods $src.LocalMods -BackupRoot $backupRoot | Out-Null
    } catch { Write-Fail $_.Exception.Message } finally { Set-Busy $false }
})

$btnApply.Add_Click({
    $ans = [System.Windows.Forms.MessageBox]::Show(
        "ModsConfig.xml 을 덮어쓴다.`n기존 파일은 날짜가 붙은 이름으로 백업한다.`n`n계속할까?",
        "적용", 'YesNo', 'Warning')
    if ($ans -ne 'Yes') { return }
    Set-Busy $true
    try {
        $rw = Get-RimWorld
        if (Test-OneDrivePath $rw) { throw "OneDrive 경로에는 설치하지 않는다." }
        $missing = @($manifest.requiredDlc | Where-Object { -not (Test-Path (Join-Path $rw "Data\$_")) })
        if ($missing.Count) { throw "DLC 가 없다: $($missing -join ', ')" }

        $set = Build-Selection
        $live = Join-Path (Get-ConfigFolder) "ModsConfig.xml"
        $ver = Get-GameVersionFromConfig -Path $live
        if (-not $ver) { $ver = Get-GameVersionFromConfig -Path (Join-Path $repoRoot "config\ModsConfig.xml") }
        $xml = New-ModsConfigXml -Manifest $manifest -Enabled $set -GameVersion $ver

        $backup = Backup-ModsConfig -Path $live -Tag "ui"
        if ($backup) { Write-Ok "백업 : $backup" }
        Save-ModsConfig -Text $xml -Path $live
        Write-Ok "적용 : $live"

        $rimsort = $null
        if ($chkRimSort.Checked -or $chkDds.Checked) {
            $rimsort = Install-RimSort -InstallRoot "C:\Tools\RimSort"
        }
        if ($chkDds.Checked) {
            $todds = if ($rimsort) { $rimsort.ToddsExe } else { Find-Todds }
            if (-not $todds) { Write-Fail "todds 를 찾지 못했다" }
            else {
                $targets = New-ToddsTargetList -RepoRoot $repoRoot -RimWorldPath $rw
                Show-DdsPlan -Targets $targets -ToddsExe $todds
                $go = [System.Windows.Forms.MessageBox]::Show(
                    "DDS 변환을 시작한다.`n`n· 디스크 약 +6GB`n· 6코어 기준 약 54분`n· 되돌리려면 todds --clean`n`n계속할까?",
                    "DDS 변환", 'YesNo', 'Warning')
                if ($go -eq 'Yes') {
                    if (Invoke-DdsConversion -ToddsExe $todds -TargetFile $targets.Path -OverwriteNew) {
                        Invoke-DdsPrune -RepoRoot $repoRoot | Out-Null
                    }
                } else { Write-Info "DDS 변환을 건너뛴다" }
            }
        }
        Write-Step "끝. RimWorld 를 켜고 모드 목록에 빨간 느낌표가 없는지 봐라"
    } catch { Write-Fail $_.Exception.Message } finally { Set-Busy $false }
})

# ── 시작 ──────────────────────────────────────────────────────────
$detected = Find-RimWorldPath
if ($detected) { $txtPath.Text = $detected }
Refresh-Dlc
Refresh-Summary
Write-Step "$($manifest.packName) / $($manifest.packVersion) / 모드 $($manifest.mods.Count)개"
Write-Info "먼저 '미리보기' 로 무엇이 들어가는지 확인해라. 아무것도 바꾸지 않는다."

[void]$form.ShowDialog()
