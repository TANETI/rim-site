﻿<#
.SYNOPSIS
  RimSort 확보. GitHub 최신 릴리스를 받아 풀어 둔다.

.DESCRIPTION
  이 파일은 dot-source 로만 쓴다.

  RimSort 를 받는 이유가 둘이다.
    1. 모드 순서·의존성을 사용자가 직접 확인·관리할 도구
    2. **todds 가 RimSort 안에 들어 있다** — DDS 변환에 쓴다
       RimSort\todds\todds.exe

  그래서 DDS 변환을 하려면 RimSort 를 받는 것으로 충분하다.
  todds 를 따로 구할 필요가 없다.

  내려받는 크기가 약 200MB 다. 이미 있으면 다시 받지 않는다.
#>

$script:RimSortRepo = "RimSort/RimSort"

# 이미 있는 RimSort 를 찾는다. 200MB 를 다시 받지 않기 위해서다.
function Find-RimSort {
    param([string[]]$ExtraRoots = @())

    $roots = @(
        "C:\Tools\RimSort",
        (Join-Path $env:LOCALAPPDATA "RimSort"),
        (Join-Path $env:ProgramFiles "RimSort"),
        (Join-Path ${env:ProgramFiles(x86)} "RimSort"),
        (Join-Path $env:USERPROFILE "RimSort"),
        (Join-Path $env:USERPROFILE "Downloads")
    ) + $ExtraRoots | Where-Object { $_ -and (Test-Path $_) }

    foreach ($root in $roots) {
        # 설치 구조가 RimSort\RimSort\RimSort.exe 인 경우가 있어 두 단계까지 본다.
        $hits = @(Get-ChildItem $root -Filter "RimSort.exe" -Recurse -Depth 3 -ErrorAction SilentlyContinue)
        if ($hits.Count) {
            $exe = $hits[0].FullName
            return [pscustomobject]@{
                Root      = $root
                Exe       = $exe
                Home      = (Split-Path $exe -Parent)
                ToddsExe  = (Get-ToddsPathUnder (Split-Path $exe -Parent))
            }
        }
    }
    return $null
}

function Get-ToddsPathUnder {
    param([Parameter(Mandatory)][string]$RimSortHome)
    $p = Join-Path $RimSortHome "todds\todds.exe"
    if (Test-Path $p) { return $p }
    $hit = @(Get-ChildItem $RimSortHome -Filter "todds.exe" -Recurse -Depth 3 -ErrorAction SilentlyContinue)
    if ($hit.Count) { return $hit[0].FullName }
    return $null
}

function Get-RimSortLatestAsset {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $uri = "https://api.github.com/repos/$($script:RimSortRepo)/releases/latest"
    $rel = Invoke-RestMethod -Uri $uri -Headers @{ "User-Agent" = "crimson-concord-installer" } -TimeoutSec 30

    # Windows 는 .msi 와 .zip 둘 다 올라온다. 설치기는 관리자 권한을 요구하지 않으므로 zip 을 쓴다.
    $asset = $rel.assets | Where-Object { $_.name -like "*Windows*x86_64*.zip" } | Select-Object -First 1
    if (-not $asset) { throw "최신 릴리스($($rel.tag_name))에 Windows zip 자산이 없다." }

    return [pscustomobject]@{
        Tag  = $rel.tag_name
        Name = $asset.name
        Url  = $asset.browser_download_url
        Size = $asset.size
    }
}

<#
  큰 파일은 Invoke-WebRequest 대신 WebClient 를 쓴다.
  PowerShell 5.1 의 Invoke-WebRequest 는 진행률을 그리느라 200MB 에서 몇 배 느려진다.
#>
function Get-FileWithProgress {
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][string]$OutFile,
        [long]$ExpectedSize = 0
    )
    $dir = Split-Path $OutFile -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add("User-Agent", "crimson-concord-installer")
    try {
        $wc.DownloadFile($Url, $OutFile)
    } finally {
        $wc.Dispose()
    }

    if (-not (Test-Path $OutFile)) { throw "내려받기에 실패했다: $Url" }
    $actual = (Get-Item $OutFile).Length
    if ($ExpectedSize -gt 0 -and $actual -ne $ExpectedSize) {
        Remove-Item $OutFile -Force -ErrorAction SilentlyContinue
        throw "크기가 다르다. 받다 끊긴 것으로 본다 (기대 $ExpectedSize / 실제 $actual)."
    }
    return $OutFile
}

<#
  RimSort 를 확보한다. 이미 있으면 그대로 쓴다.
  -Force 면 있어도 새로 받는다.
#>
function Install-RimSort {
    param(
        [Parameter(Mandatory)][string]$InstallRoot,
        [string]$CacheDir,
        [switch]$Force
    )
    if (-not $Force) {
        $found = Find-RimSort -ExtraRoots @($InstallRoot)
        if ($found) {
            Write-Ok "RimSort 가 이미 있다: $($found.Exe)"
            if ($found.ToddsExe) { Write-Info "todds : $($found.ToddsExe)" }
            else { Write-Warn "이 RimSort 안에 todds 가 없다. DDS 변환은 건너뛰게 된다" }
            return $found
        }
    }

    Write-Step "RimSort 내려받기"
    $asset = Get-RimSortLatestAsset
    $mb = [math]::Round($asset.Size / 1MB, 1)
    Write-Info "$($asset.Tag) / $($asset.Name) / ${mb}MB"
    Write-Info "todds 가 이 안에 들어 있다. DDS 변환도 이걸로 한다."

    if (-not $CacheDir) { $CacheDir = Join-Path $env:TEMP "crimson-concord-installer" }
    $zip = Join-Path $CacheDir $asset.Name

    if ((Test-Path $zip) -and (Get-Item $zip).Length -eq $asset.Size) {
        Write-Info "이미 받아 둔 파일을 쓴다: $zip"
    } else {
        Write-Info "받는 중... 회선에 따라 몇 분 걸린다"
        Get-FileWithProgress -Url $asset.Url -OutFile $zip -ExpectedSize $asset.Size | Out-Null
        Write-Ok "내려받기 완료"
    }

    if (-not (Test-Path $InstallRoot)) { New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null }
    Write-Info "푸는 중: $InstallRoot"
    Expand-Archive -Path $zip -DestinationPath $InstallRoot -Force

    $found = Find-RimSort -ExtraRoots @($InstallRoot)
    if (-not $found) { throw "풀었는데 RimSort.exe 를 찾지 못했다: $InstallRoot" }

    Write-Ok "RimSort : $($found.Exe)"
    if ($found.ToddsExe) { Write-Ok "todds   : $($found.ToddsExe)" }
    else { Write-Warn "todds 를 찾지 못했다. DDS 변환은 건너뛴다" }
    return $found
}
