﻿<#
.SYNOPSIS
  활성 모드의 Textures 폴더 목록을 만들어 todds 입력 파일로 저장한다.

.DESCRIPTION
  config/ModsConfig.xml의 활성 목록을 읽고, 각 packageId에 해당하는 실제 모드 폴더를
  Workshop 및 Mods 디렉터리에서 찾아 그 안의 Textures 폴더 경로를 모은다.

  공식 DLC(Core/Royalty/Ideology/Biotech/Odyssey)는 Data 폴더에 번들로 들어 있어
  낱개 PNG가 없으므로 매칭되지 않는 것이 정상이다.

  경로는 컴퓨터마다 다르므로 고정하지 않고 탐지한다. 탐지에 실패하면 -RimWorldPath로 지정한다.

.EXAMPLE
  .\scripts\build-todds-targets.ps1
  .\scripts\build-todds-targets.ps1 -RimWorldPath "D:\Steam\steamapps\common\RimWorld"
#>
[CmdletBinding()]
param(
    [string]$RimWorldPath,
    [string]$OutFile = ".todds-targets.txt"
)

$ErrorActionPreference = "Stop"

function Find-RimWorld {
    $candidates = @(
        "C:\Program Files (x86)\Steam\steamapps\common\RimWorld",
        "C:\Program Files\Steam\steamapps\common\RimWorld",
        "D:\Steam\steamapps\common\RimWorld",
        "D:\SteamLibrary\steamapps\common\RimWorld",
        "E:\SteamLibrary\steamapps\common\RimWorld"
    )
    # Steam 라이브러리 폴더 목록도 훑는다
    foreach ($vdf in @("C:\Program Files (x86)\Steam\steamapps\libraryfolders.vdf",
                       "C:\Program Files\Steam\steamapps\libraryfolders.vdf")) {
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s*"([^"]+)"')) {
                $candidates += (Join-Path ($m.Groups[1].Value -replace '\\', '\') "steamapps\common\RimWorld")
            }
        }
    }
    foreach ($c in $candidates) {
        if (Test-Path (Join-Path $c "RimWorldWin64.exe")) { return $c }
    }
    return $null
}

if (-not $RimWorldPath) { $RimWorldPath = Find-RimWorld }
if (-not $RimWorldPath) {
    throw "RimWorld 설치 경로를 찾지 못했다. -RimWorldPath 로 직접 지정해라."
}
Write-Host ("RimWorld : " + $RimWorldPath)

$repoRoot  = Split-Path $PSScriptRoot -Parent
$modsConfig = Join-Path $repoRoot "config\ModsConfig.xml"
if (-not (Test-Path $modsConfig)) { throw "config\ModsConfig.xml 을 찾지 못했다: $modsConfig" }

# PowerShell 5.1의 Get-Content 기본 인코딩은 시스템 ANSI다.
# 한글/일본어가 든 About.xml이 깨져 XML 파싱에 실패하므로 UTF-8을 명시해 읽는다.
function Read-XmlUtf8([string]$path) {
    try { return [xml][System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8) } catch { return $null }
}

$active = (Read-XmlUtf8 $modsConfig).ModsConfigData.activeMods.li |
          ForEach-Object { $_.Trim().ToLower() }
Write-Host ("활성 모드 : " + $active.Count)

$steamApps = Split-Path (Split-Path $RimWorldPath -Parent) -Parent
$roots = @(
    (Join-Path $steamApps "workshop\content\294100"),
    (Join-Path $RimWorldPath "Mods")
) | Where-Object { Test-Path $_ }

$matched = @{}
foreach ($root in $roots) {
    foreach ($dir in Get-ChildItem $root -Directory -ErrorAction SilentlyContinue) {
        $about = Join-Path $dir.FullName "About\About.xml"
        if (-not (Test-Path $about)) { continue }
        $xml = Read-XmlUtf8 $about
        if (-not $xml) { Write-Warning ("About.xml 읽기 실패: " + $about); continue }
        $pid_ = $xml.ModMetaData.packageId
        if (-not $pid_) { continue }
        $pid_ = $pid_.Trim().ToLower()
        if ($active -contains $pid_) { $matched[$pid_] = $dir.FullName }
    }
}
Write-Host ("폴더 매칭   : " + $matched.Count)
$unmatched = $active | Where-Object { -not $matched.ContainsKey($_) }
if ($unmatched) { Write-Host ("매칭 안 됨  : " + ($unmatched -join ", ")) }

$tex = @()
foreach ($p in $matched.Values) {
    $tex += Get-ChildItem $p -Directory -Recurse -Filter "Textures" -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty FullName
}
# PNG가 하나도 없는 Textures 폴더는 제외한다.
# todds는 그런 폴더를 "PNG 파일도 디렉터리도 아니다"라며 오류로 처리하고 그 지점에서 멈춘다.
# 주의: @($null).Count 는 0이 아니라 1이다. 반드시 Select-Object -First 1 로 판정한다.
$tex = $tex | Sort-Object -Unique | Where-Object {
    $null -ne (Get-ChildItem $_ -Recurse -Include *.png -File -ErrorAction SilentlyContinue |
               Select-Object -First 1)
}
Write-Host ("Textures 폴더: " + $tex.Count)

$outPath = Join-Path $repoRoot $OutFile
# 주의: PowerShell 5.1의 Set-Content -Encoding utf8 은 BOM을 붙인다.
# todds는 첫 줄 맨 앞의 BOM을 경로의 일부로 읽어 "PNG 파일도 디렉터리도 아니다"로 실패한다.
# BOM 없는 UTF-8로 써야 한다.
[System.IO.File]::WriteAllLines($outPath, [string[]]$tex, (New-Object System.Text.UTF8Encoding $false))
Write-Host ("목록 저장    : " + $outPath)

$png = 0; $bytes = 0
foreach ($t in $tex) {
    $f = Get-ChildItem $t -Recurse -Include *.png -File -ErrorAction SilentlyContinue
    $png += $f.Count; $bytes += ($f | Measure-Object Length -Sum).Sum
}
Write-Host ("대상 PNG     : {0}개 / {1:N0} MB" -f $png, ($bytes/1MB))
