﻿<#
.SYNOPSIS
  DDS 변환. todds 는 RimSort 안에 들어 있는 것을 쓴다.

.DESCRIPTION
  이 파일은 dot-source 로만 쓴다.

  ── 왜 하나 ────────────────────────────────────────────────────────
  부팅 시간이 줄어든다. 데스크탑에서 약 90초까지 내려갔다.
  자세한 것은 docs/DDS-CONVERSION-2026-08-30.md.

  ── 알고 있어야 하는 것 ────────────────────────────────────────────
  · 시간이 오래 걸린다. 노트북(i3-1315U)에서 17,097개에 약 54분.
    완전히 CPU 병목이라 코어가 많으면 그만큼 빨라진다.
  · 디스크가 약 6GB 늘어난다. PNG 는 지우지 않고 DDS 를 나란히 만든다.
  · 🔴 가로·세로가 4의 배수가 아닌 이미지도 todds 는 DDS 를 만든다.
    그런데 Unity 가 로드를 거부한다. 그대로 두면 부팅 로그에 오류가 쌓인다.
    변환 뒤 반드시 prune-failed-dds.ps1 로 걸러야 한다.
    (이 문서의 옛 판이 "4의 배수가 아니면 DDS 가 안 생긴다" 고 적어 뒀는데 사실이 아니었다)
  · 되돌리려면 todds --clean 을 쓴다. PNG 는 그대로이므로 화면은 달라지지 않는다.
#>

function Find-Todds {
    param([string]$RimSortHome)
    if ($RimSortHome) {
        $p = Join-Path $RimSortHome "todds\todds.exe"
        if (Test-Path $p) { return $p }
    }
    $cmd = Get-Command "todds" -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

<#
  변환 대상 목록을 만든다. 기존 scripts/build-todds-targets.ps1 을 그대로 쓴다.
  활성 배열이 바뀌었을 수 있으므로 변환 직전에 매번 새로 만든다.
#>
function New-ToddsTargetList {
    param(
        [Parameter(Mandatory)][string]$RepoRoot,
        [Parameter(Mandatory)][string]$RimWorldPath,
        [string]$OutFile
    )
    if (-not $OutFile) { $OutFile = Join-Path $RepoRoot ".todds-targets.txt" }
    $builder = Join-Path $RepoRoot "scripts\build-todds-targets.ps1"
    if (-not (Test-Path $builder)) { throw "build-todds-targets.ps1 이 없다: $builder" }

    & $builder -RimWorldPath $RimWorldPath -OutFile $OutFile | Out-Null
    if (-not (Test-Path $OutFile)) { throw "대상 목록이 만들어지지 않았다: $OutFile" }

    $count = @(Get-Content $OutFile | Where-Object { $_.Trim() }).Count
    return [pscustomobject]@{ Path = $OutFile; FolderCount = $count }
}

<#
  변환 전에 무엇이 벌어지는지 먼저 보여주고 동의를 받는다.
  54분과 6GB 는 아무 말 없이 시작할 규모가 아니다.
#>
function Show-DdsPlan {
    param(
        [Parameter(Mandatory)]$Targets,
        [Parameter(Mandatory)][string]$ToddsExe
    )
    Write-Step "DDS 변환 계획"
    Write-Info "todds       : $ToddsExe"
    Write-Info "대상 폴더    : $($Targets.FolderCount)개 (활성 모드의 Textures)"
    Write-Info ""
    Write-Info "이걸 하면"
    Write-Info "  · 부팅이 빨라진다 (이 팩 실측: 데스크탑 약 90초)"
    Write-Info "  · 디스크가 약 6GB 늘어난다. PNG 는 지우지 않는다"
    Write-Info "  · CPU 를 오래 쓴다. 6코어 노트북 기준 약 54분, 코어가 많으면 그만큼 짧다"
    Write-Info "  · 언제든 todds --clean 으로 되돌릴 수 있다"
    Write-Info ""
    Write-Warn "변환 뒤 4의 배수가 아닌 이미지의 DDS 를 걸러내야 한다."
    Write-Info "  설치기가 이어서 자동으로 해 준다 (prune-failed-dds.ps1)"
}

<#
  🔴 `-vf` 를 빼면 텍스처가 전부 위아래로 뒤집힌다.

  DDS 는 아래에서 위로 저장하고 PNG 는 위에서 아래로 저장한다.
  todds 는 그 차이를 자동으로 맞춰 주지 않으므로 우리가 지시해야 한다.

  이걸 두 번 빠뜨렸다. 2026-09-01 에도 그랬다.
  원인은 문서 쪽이었다 — 목차에는 "텍스처 뒤집힘" 이라고 적어 뒀는데
  정작 본문의 명령 예시 일곱 군데에 `-vf` 가 하나도 없었다.
  그래서 여기서는 옵션으로 두지 않고 **항상 붙인다.**
  끄고 싶으면 `-NoVerticalFlip` 을 명시해야 한다.
#>
function Invoke-DdsConversion {
    param(
        [Parameter(Mandatory)][string]$ToddsExe,
        [Parameter(Mandatory)][string]$TargetFile,
        [switch]$OverwriteNew,
        [switch]$Overwrite,
        [int]$Threads = 0,
        [switch]$NoVerticalFlip
    )
    $args = @("--progress", "--time")
    if (-not $NoVerticalFlip) { $args += "--vflip" }
    if ($Overwrite)    { $args += "--overwrite" }
    elseif ($OverwriteNew) { $args += "--overwrite-new" }
    if ($Threads -gt 0) { $args += @("--threads", "$Threads") }
    $args += $TargetFile

    Write-Info ("옵션 : " + ($args[0..($args.Count - 2)] -join " "))

    Write-Step "DDS 변환 시작 — 오래 걸린다. 중간에 창을 닫지 마라"
    $started = Get-Date
    & $ToddsExe @args
    $code = $LASTEXITCODE
    $elapsed = (Get-Date) - $started

    if ($code -ne 0) {
        Write-Fail "todds 가 $code 로 끝났다"
        return $false
    }
    Write-Ok ("변환 완료 — {0:hh\:mm\:ss}" -f $elapsed)
    return $true
}

<#
  4의 배수가 아닌 이미지의 DDS 를 지운다.
  이 단계를 빼면 부팅 로그에 Texture2D 로드 실패가 쌓인다.
#>
<#
  걸러내기는 두 가지다. **치수 기반을 먼저 돌린다.**

    1. 치수 기반 (prune-nonmultiple4-dds.ps1)
       원본 PNG 헤더에서 가로·세로를 읽어 4의 배수가 아니면 지운다.
       부팅이 필요 없고 한 번에 전부 걸러진다.

    2. 로그 기반 (prune-failed-dds.ps1)
       Player.log 에 실제로 찍힌 실패만 지운다.
       텍스처는 지연 로드라 한 번의 부팅으로 전부 드러나지 않는다.
       치수 기반이 놓친 다른 원인(손상된 PNG 등)을 잡는 보조 수단이다.

  변환 직후에는 로그에 아무것도 없으므로 2번은 건너뛴다.
  부팅한 뒤에 따로 돌리면 된다.
#>
function Invoke-DdsPrune {
    param(
        [Parameter(Mandatory)][string]$RepoRoot,
        [switch]$IncludeLogBased
    )
    $ok = $true

    $bySize = Join-Path $RepoRoot "scripts\prune-nonmultiple4-dds.ps1"
    if (Test-Path $bySize) {
        Write-Step "4의 배수가 아닌 이미지의 DDS 걸러내기"
        & $bySize
    } else {
        Write-Warn "prune-nonmultiple4-dds.ps1 이 없다. Unity 가 거부할 DDS 가 남는다"
        $ok = $false
    }

    if ($IncludeLogBased) {
        $byLog = Join-Path $RepoRoot "scripts\prune-failed-dds.ps1"
        if (Test-Path $byLog) {
            Write-Step "로그에 남은 실패 걸러내기"
            & $byLog
        } else {
            Write-Warn "prune-failed-dds.ps1 이 없다"
        }
    } else {
        Write-Info "로그 기반 정리는 건너뛴다 — 지금은 로그에 아무것도 없다."
        Write-Info "부팅한 뒤 scripts\prune-failed-dds.ps1 을 한 번 돌리면 남은 것이 잡힌다."
    }
    return $ok
}

function Invoke-DdsClean {
    param(
        [Parameter(Mandatory)][string]$ToddsExe,
        [Parameter(Mandatory)][string]$TargetFile
    )
    Write-Step "DDS 되돌리기"
    & $ToddsExe "--clean" $TargetFile
    if ($LASTEXITCODE -eq 0) { Write-Ok "DDS 를 지웠다. PNG 는 그대로다" }
}
