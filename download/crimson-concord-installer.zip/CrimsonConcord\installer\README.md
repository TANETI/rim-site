# 진조이니라! 모드팩 설치기

RimWorld 1.6 모드팩을 재현 가능하게 구성하는 도구다.

## 이 도구가 하는 일 셋 (2026-09-01 범위 확정)

1. **우리가 만든 모드를 설치·갱신한다** — 자작 20개
2. **배열을 정리한다** — `ModsConfig.xml` 생성
3. **RimSort 를 받아 준다** — todds 가 그 안에 있어 DDS 변환까지

## 하지 않는 일

**Workshop 모드를 대신 받지 않는다.** 각자 Steam 에서 구독한다.

SteamCMD 자동 다운로드는 2026-09-01 에 걷어냈다.
한 번도 실전에서 돌지 않은 기능이었고(만든 컴퓨터에는 받을 대상이 0개였다),
같이 할 사람들이 직접 받겠다고 해서 필요가 없어졌다.
`installer/lib/SteamCmd.ps1` 은 지웠다. 되살릴 일이 있으면 git 이력에 있다.

대신 **무엇이 없는지 목록과 워크샵 링크를 `installer/missing-mods.txt` 로 뽑아 준다.**
그것만 보고 구독한 뒤 다시 돌리면 된다. 다 받으면 그 파일은 지워진다.

## 준비할 것

- RimWorld 1.6
- DLC 4종 — Royalty, Ideology, Biotech, Odyssey (설치기가 검사하고, 없으면 멈춘다)
- PowerShell 5.1 (Windows 기본)
- OneDrive 폴더에 RimWorld 를 두지 말 것 (설치기가 검사하고 멈춘다)

## 창으로 쓰기 — 처음이면 이쪽

```bash
powershell -ExecutionPolicy Bypass -File installer\Modpack-UI.ps1
```

왼쪽에서 넣을 묶음을 고르고, 오른쪽에서 위생 갈래를 고르고, 아래 버튼을 누르면 된다.

| 버튼 | 하는 일 |
|---|---|
| **미리보기** | 아무것도 바꾸지 않고 결과만 `installer/ModsConfig.preview.xml` 에 쓴다 |
| **없는 모드 목록** | 구독하지 않은 모드를 링크와 함께 `missing-mods.txt` 로 뽑고 연다 |
| **자작 모드 설치** | 우리가 만든 모드를 설치본에 깔거나 최신본으로 덮는다 |
| **적용** | 배열을 실제로 반영한다. 기존 파일은 날짜 백업 |

긴 작업이 도는 동안 창이 멈춘 것처럼 보인다. **진행 상황은 아래 로그 칸에 계속 올라온다.**
닫지 말고 기다리면 된다.

## 명령줄로 쓰기

```powershell
# 무엇을 할지 보기만 한다. 아무것도 바꾸지 않는다
.\installer\Install-Modpack.ps1

# 물어보면서 진행
.\installer\Install-Modpack.ps1 -Interactive -Apply

# 위생 갈래를 미리 정해서
.\installer\Install-Modpack.ps1 -Apply -Hygiene lite

# 배열만. 자작 모드는 건드리지 않는다
.\installer\Install-Modpack.ps1 -Apply -SkipLocalMods

# RimSort 받고 DDS 변환까지
.\installer\Install-Modpack.ps1 -Apply -WithRimSort -WithDds
```

`-Apply` 가 없으면 실제 `ModsConfig.xml` 을 건드리지 않고
`installer\ModsConfig.preview.xml` 에만 결과를 써 둔다. 먼저 이걸로 확인해라.

`-Apply` 를 쓰면 기존 `ModsConfig.xml` 을 **날짜가 붙은 이름으로 백업**한 뒤 덮어쓴다.

## 위생 갈래 — 셋 중 하나를 고른다

`-Hygiene none|lite|full`. 기본값은 **lite** 다.

| 갈래 | 무엇이 달라지나 |
|---|---|
| `none` | 위생 욕구 자체가 없다. 관리할 것이 하나 줄어든다.<br>발정 해소의 목욕·샤워 경로(0.55 / 0.40)와 온천 자판기가 함께 사라진다 |
| `lite` | **이 팩이 실제로 검증한 구성.** 씻기와 화장실만, 배관 공사 없음.<br>수영장 길찾기 보정과 온천 자판기가 함께 들어간다 |
| `full` | 원본 Dubs Bad Hygiene. 배관·수도·정화조까지 전부 |

⚠ **`full` 은 아직 이 팩에서 부팅 검증을 하지 않았다.** 고르면 설치기가 경고한다.
우리 호환 패치 두 개(수영장 길찾기, 온천 자판기 재포장본)는 Lite 전용이라 함께 빠지고,
원본 Dubs Bad Hygiene 은 따로 구독해야 한다.

발정 해소의 목욕·샤워 판정은 JobDef **이름**으로 하므로
(`takeBath` / `UseHotTub` / `UseSauna` / `takeShower` 등) 원본에서도 이름이 같으면 동작한다.

## 성인 요소 — 별개 축이다 (2026-09-01)

`-Adult off|on`. 기본값은 **off** 다.

| | 활성 개수 (위생 lite 기준) |
|---|---:|
| `-Adult off` | 127 |
| `-Adult on` | **128 — 부팅 검증을 마친 그 배열이다** |

예전에는 프리셋이 이것을 함께 정했다(입문 세트를 고르면 자동으로 빠졌다).
**난이도와 성인 요소는 관계가 없으므로** 갈래로 떼어냈다 —
초보인데 원할 수도, 오래 한 사람인데 원치 않을 수도 있다.

기본값을 끔으로 둔 것은 공개 사이트에서 받는 사람이 먼저 만나는 값이기 때문이다.
빠져도 진조의 정체성(흡혈·혈통·각성)은 남는다. 그렇게 되도록 모듈을 갈라 뒀다.

```bash
# 검증된 128개 그대로
.\installer\Install-Modpack.ps1 -Apply -Hygiene lite -Adult on
```

## 없는 모드 목록

받아 주지 않는다. **무엇이 없는지만 알려 준다.**

- 배열에 필요한데 이 컴퓨터에 없는 모드를 골라
  `installer/missing-mods.txt` 에 이름·packageId·워크샵 링크로 적는다.
- 다 구독하고 다시 돌리면 그 파일은 지워진다.
- 워크샵에서 내려간 모드(`obtainable: false`)는 애초에 배열에 넣지 않는다.
- 우리 자작 모드는 이 목록에 오르지 않는다. 설치기가 직접 깔기 때문이다.

## 자작 모드 설치·갱신 — 이 도구의 본업

Workshop 모드 99개는 Steam 이 알아서 갱신하고 RimSort 가 알려 준다.
**우리가 직접 챙겨야 하는 것은 우리가 만든 것뿐**이다 — 진조이니라 본체와 선택 모듈,
호환 패치, 한국어 보정.

버전 표기를 새로 만들어 붙이는 대신 **파일 내용 해시**로 비교한다.

```
모드 폴더의 모든 파일을 상대 경로 순으로 정렬
  → 각 파일의 SHA-256 을 이어 붙여 다시 SHA-256
  → 그 값이 그 모드의 지문
```

버전 문자열을 올리는 것을 잊어도 어긋나지 않는다.
`Source\`, `.git`, `README.md`, `.psd` 는 설치본에 가지 않으므로 지문에서 뺀다.

`-Apply` 면 기본으로 돈다. 배열만 만들고 싶으면 `-SkipLocalMods`.
**설치와 갱신이 같은 경로다** — 설치본에 없으면 새로 깔고, 있으면 바뀐 것만 덮는다.

가져올 곳은 `-UpdateSource` 로 정한다.

| 형식 | 뜻 |
|---|---|
| `local:경로` | 이미 있는 작업 사본에서 가져온다 **(지금 동작하는 것)** |
| `github:소유자/저장소[@가지]` | 공개 저장소의 zip 을 받는다 |

기본값은 `local:<이 저장소>` 다.

> 🔴 **`github:` 를 쓰려면 공개 미러 저장소가 먼저 있어야 한다.**
> 이 저장소는 Private 이고, 설치기는 토큰을 다루지 않는다.
> `local-mods` 만 담은 공개 저장소를 따로 두는 것이 설계 4절의 B안이다. 아직 만들지 않았다.

갱신할 때 **설치본에만 있는 파일은 지운다.** 옛 Def 가 남아 교차참조 오류를 내는 것을 막기 위해서다.
단 `CrimsonConcord/Defs/00.png` 은 저장소 규약상 동기화 대상이 아니라 건드리지 않는다.

### 덮어쓰기 전에 두 가지를 한다 (2026-09-01)

**1. 백업.** 설치본을 통째로 복사해 둔다.

```
%LOCALAPPDATA%\CrimsonConcord\mod-backups\<yyyyMMdd-HHmmss>\<모드이름>\
```

백업에 실패하면 그 모드는 아예 건드리지 않는다. 끄려면 `-NoBackup` 을 명시해야 한다.
게임 폴더 안에 두지 않는다 — RimWorld 와 RimSort 가 모드로 오인한다.

**2. 무결성 대조.** 원본 옆에 `local-mods.index.json` 이 있으면 파일별 SHA-256 으로
대조한다. 한 파일이라도 다르거나, 없거나, 색인에 없는 여분이 있으면
**그 모드는 통째로 건너뛴다.** 반만 맞은 설치가 가장 고치기 어렵다.

색인은 사이트 빌드가 함께 낸다.

```
.\scripts\build-local-mods-index.ps1
```

> 🔴 이건 **손상 검출**이다. 진위 검증이 아니다.
> 색인도 같은 배포처에서 오므로 배포처 자체가 바뀐 경우는 못 잡는다.
> 서명은 하지 않는다. 이 문장을 "안전하게 검증한다" 로 고치지 마라.

## RimSort 와 DDS 는 한 번에 해결된다

**todds 가 RimSort 안에 들어 있다** (`RimSort\todds\todds.exe`).
그래서 DDS 변환을 고르면 설치기가 RimSort 를 먼저 확보한다. todds 를 따로 구할 필요가 없다.

RimSort 는 GitHub 최신 릴리스의 Windows **zip** 을 받아 푼다(약 200MB).
`.msi` 가 아니라 zip 인 것은 관리자 권한을 요구하지 않기 위해서다.
이미 있으면 다시 받지 않는다. `-RimSortRoot` 로 위치를 정할 수 있다(기본 `C:\Tools\RimSort`).

DDS 변환은 시작 전에 이걸 먼저 보여주고 동의를 받는다.

- 부팅이 빨라진다 (이 팩 실측: 데스크탑 약 90초)
- 디스크가 약 6GB 늘어난다. PNG 는 지우지 않는다
- CPU 를 오래 쓴다. 6코어 노트북 기준 약 54분
- `todds --clean` 으로 언제든 되돌릴 수 있다

변환이 끝나면 **가로·세로가 4의 배수가 아닌 이미지의 DDS 를 자동으로 걸러낸다.**
todds 는 그런 이미지에도 DDS 를 만드는데 Unity 가 로드를 거부하기 때문이다.
이 단계를 빼면 부팅 로그에 `Texture2D` 로드 실패가 쌓인다.

## 개발자용 — 매니페스트 관리

설치기의 모든 판단은 `installer\modpack.manifest.json` 하나에서 나온다.
**이 파일을 직접 고치지 마라.** 생성물이다.

```powershell
# config/ModsConfig.xml + 실제 설치본 → 매니페스트
.\scripts\build-manifest.ps1

# 매니페스트 ↔ ModsConfig 정합성 검사
.\scripts\verify-manifest.ps1
```

고칠 것은 `installer\manifest-overrides.json` 이다. 여기에는 **사람이 정하는 값**만 둔다.

| | 어디서 오나 |
|---|---|
| packageId, name, author, workshopId, order, About 의존성 | 기계가 매번 새로 뽑는다 |
| group, required, defaultEnabled, obtainable, note, requires, adultContent, variant | 사람이 정한다 (overrides) |

**배열을 바꾼 뒤에는 반드시 이 둘을 순서대로 돌린다.** 안 그러면 설치기가 낡은 목록을 배포한다.

`verify-manifest.ps1` 의 가장 중요한 검사는 마지막 것이다 —
매니페스트로 만든 `ModsConfig.xml` 이 검증된 `config/ModsConfig.xml` 과 같은지 대조한다.
여기서 어긋나면 나머지가 전부 무의미하다.

## 구현 상태

| 단계 | 상태 |
|---|---|
| 1. 매니페스트 생성·검사 | ✅ |
| 2. 경로 탐지 + DLC 검사 + ModsConfig 생성 | ✅ |
| 3. ~~SteamCMD 다운로드~~ | 🗑 2026-09-01 철회. 각자 구독한다 |
| 4. 상태 파일 기반 이어하기 | ❌ 미착수 |
| 5. 커스터마이징 화면 | ✅ 창 + 명령줄 |
| 6. RimSort · DDS | ✅ |
| 7. 설명서 | ✅ 이 문서 |
| — 자작 모드 설치·갱신 | ✅ 이제 이 도구의 본업이다 |

설계 전문은 `docs/MODPACK-INSTALLER-DESIGN-2026-08-30.md`.

### 실제로 돌려 본 것

- **RimSort 설치.** 2026-09-01 에 이 설치기로 데스크탑에 깔았다.
  v1.12.0 / 199.2MB → `C:\Tools\RimSort\RimSort\RimSort.exe`,
  `C:\Tools\RimSort\RimSort\todds\todds.exe` (todds 0.4.1, `--help` 로 실행 확인).
  다시 불렀을 때 받지 않고 건너뛰는 것도 확인했다.

### 아직 시험하지 못한 것

- **`github:` 원본.** 공개 미러 저장소가 없어 `local:` 만 실제로 돌려 봤다.
- **UI 실물.** 구문은 통과하지만 창을 한 번도 열어 보지 않았다.

## 알아 둘 제약

- **모드팩 zip 배포는 불가능하다.** Workshop 모드 다수가 재배포를 금지한다.
  설치기가 옮기는 것은 우리가 만든 것과 목록·순서뿐이다.
- **Workshop 모드는 계속 바뀐다.** 특정 시점 버전을 고정할 방법이 없다.
  "이 커밋 기준으로 동작을 확인했다" 까지만 보장할 수 있다.
- **`dev.soeur.imageopt` 는 2026-08-30 워크샵에서 삭제됐다.** 신규 구독이 안 된다.
  2026-09-01 에 배열에서도 뺐다. 이미 깔려 있는 컴퓨터에서만 유지하고
  새로 만드는 배열에는 넣지 않는다. 부팅 속도는 DDS 변환이 대신한다.
