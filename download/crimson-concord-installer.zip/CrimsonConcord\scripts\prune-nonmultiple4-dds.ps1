﻿<#
.SYNOPSIS
  가로·세로가 4의 배수가 아닌 이미지의 DDS 를 지운다. 부팅이 필요 없다.

.DESCRIPTION
  BC7 은 가로·세로가 4의 배수인 텍스처만 받는다. 그런데 todds 는 그렇지 않은
  이미지에도 DDS 를 만들고, Unity 가 로드 단계에서 거부한다.

    Compressed TextureFormat RGB(A) Compressed BC7 requires a texture size
    that is a multiple of 4
    at Verse.ModDdsLoader.CreateTexture

  `prune-failed-dds.ps1` 은 **로그에 실제로 찍힌 실패만** 지운다.
  그런데 텍스처는 지연 로드라 한 번의 부팅으로 전부 드러나지 않는다.
  2026-08-30 에 258개를 지우고 다시 부팅했더니 또 나왔다.

  이 스크립트는 원본 PNG 헤더에서 치수를 직접 읽어 **한 번에 전부** 거른다.
  부팅을 반복할 필요가 없다. 로그 기반보다 이쪽을 먼저 돌리는 것이 맞다.

  원본 PNG 는 건드리지 않는다. 해당 텍스처는 PNG 로 로드되므로 화면은 그대로다.
  todds 를 다시 돌리면 지운 DDS 가 되살아난다. 그때 이걸 한 번 더 돌린다.

.EXAMPLE
  .\scripts\prune-nonmultiple4-dds.ps1
  .\scripts\prune-nonmultiple4-dds.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$TargetFile = (Join-Path (Split-Path $PSScriptRoot -Parent) ".todds-targets.txt")
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $TargetFile)) {
    throw "대상 목록이 없다: $TargetFile`n  scripts\build-todds-targets.ps1 을 먼저 돌려라."
}

# PNG 헤더에서 가로·세로를 읽는다.
#   0~7   시그니처
#   8~11  IHDR 길이
#   12~15 "IHDR"
#   16~19 가로 (빅엔디안)
#   20~23 세로 (빅엔디안)
function Get-PngSize {
    param([string]$Path)
    try {
        $fs = [System.IO.File]::OpenRead($Path)
        try {
            $buf = New-Object byte[] 24
            if ($fs.Read($buf, 0, 24) -lt 24) { return $null }
            if ($buf[0] -ne 0x89 -or $buf[1] -ne 0x50) { return $null }   # \x89PNG 아니면 건너뛴다
            $w = ($buf[16] -shl 24) -bor ($buf[17] -shl 16) -bor ($buf[18] -shl 8) -bor $buf[19]
            $h = ($buf[20] -shl 24) -bor ($buf[21] -shl 16) -bor ($buf[22] -shl 8) -bor $buf[23]
            return [pscustomobject]@{ W = $w; H = $h }
        } finally { $fs.Dispose() }
    } catch { return $null }
}

$folders = @(Get-Content $TargetFile | Where-Object { $_.Trim() })
Write-Host ("대상 폴더 : {0}개" -f $folders.Count)

$checked = 0; $bad = 0; $removed = 0; $unreadable = 0
$examples = @()

foreach ($folder in $folders) {
    if (-not (Test-Path $folder)) { continue }
    foreach ($dds in Get-ChildItem $folder -Recurse -Filter *.dds -File -ErrorAction SilentlyContinue) {
        $png = [System.IO.Path]::ChangeExtension($dds.FullName, ".png")
        if (-not (Test-Path -LiteralPath $png)) { continue }
        $checked++

        $size = Get-PngSize $png
        if (-not $size) { $unreadable++; continue }
        if (($size.W % 4) -eq 0 -and ($size.H % 4) -eq 0) { continue }

        $bad++
        if ($examples.Count -lt 5) {
            $examples += ("{0}  ({1}x{2})" -f $dds.Name, $size.W, $size.H)
        }
        if ($PSCmdlet.ShouldProcess($dds.FullName, "삭제")) {
            Remove-Item -LiteralPath $dds.FullName -Force -ErrorAction SilentlyContinue
            $removed++
        }
    }
}

Write-Host ("검사한 DDS : {0}개" -f $checked)
Write-Host ("4의 배수 아님 : {0}개" -f $bad)
if ($examples.Count) {
    Write-Host "  예시:"
    foreach ($e in $examples) { Write-Host ("    " + $e) }
}
if ($unreadable) { Write-Host ("PNG 헤더를 못 읽음 : {0}개 (그대로 뒀다)" -f $unreadable) }
Write-Host ("삭제 : {0}개" -f $removed)
Write-Host "원본 PNG 는 건드리지 않았다. 해당 텍스처는 이제 PNG 로 로드된다."
